// Copyright 2012 Google Inc. All rights reserved.
(function() {

    var data = {
        "resource": {
            "version": "3",

            "macros": [{
                "function": "__v",
                "vtp_name": "gtm.elementClasses",
                "vtp_dataLayerVersion": 1
            }, {
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__e"
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": false,
                "vtp_setTrackerName": false,
                "vtp_useDebugVersion": false,
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": false,
                "vtp_enableEcommerce": false,
                "vtp_trackingId": "UA-25355610-1",
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableGA4Schema": false
            }, {
                "function": "__c",
                "vtp_value": "UA-25355610-1"
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }, {
                "function": "__v",
                "vtp_name": "gtm.elementId",
                "vtp_dataLayerVersion": 1
            }],
            "tags": [{
                "function": "__ua",
                "once_per_event": true,
                "vtp_nonInteraction": false,
                "vtp_overrideGaSettings": false,
                "vtp_eventValue": "Contact Us - Form",
                "vtp_eventCategory": "Form Submission",
                "vtp_trackType": "TRACK_EVENT",
                "vtp_gaSettings": ["macro", 3],
                "vtp_eventAction": "Contact Us - Form",
                "vtp_eventLabel": "Contact Us - Form",
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "vtp_trackTypeIsEvent": true,
                "vtp_enableGA4Schema": false,
                "tag_id": 1
            }, {
                "function": "__gaawc",
                "metadata": ["map"],
                "once_per_event": true,
                "vtp_sendPageView": true,
                "vtp_enableSendToServerContainer": false,
                "vtp_measurementId": "G-7H2PPM7JCT",
                "vtp_enableUserProperties": true,
                "vtp_enableEuid": false,
                "vtp_enableSendFirstPartyUserDataForSgtm": true,
                "tag_id": 9
            }, {
                "function": "__cl",
                "tag_id": 10
            }],
            "predicates": [{
                "function": "_cn",
                "arg0": ["macro", 0],
                "arg1": "wpcf7-submit"
            }, {
                "function": "_cn",
                "arg0": ["macro", 1],
                "arg1": "contact-us"
            }, {
                "function": "_eq",
                "arg0": ["macro", 2],
                "arg1": "gtm.click"
            }, {
                "function": "_eq",
                "arg0": ["macro", 2],
                "arg1": "gtm.js"
            }],
            "rules": [
                [
                    ["if", 0, 1, 2],
                    ["add", 0]
                ],
                [
                    ["if", 3],
                    ["add", 1, 2]
                ]
            ]
        },
        "runtime": []




    };


    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var h, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ca;
    if ("function" == typeof Object.setPrototypeOf) ca = Object.setPrototypeOf;
    else {
        var ea;
        a: {
            var fa = {
                    a: !0
                },
                ha = {};
            try {
                ha.__proto__ = fa;
                ea = ha.a;
                break a
            } catch (a) {}
            ea = !1
        }
        ca = ea ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ia = ca,
        ja = function(a, b) {
            a.prototype = ba(b.prototype);
            a.prototype.constructor = a;
            if (ia) ia(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.lk = b.prototype
        },
        ka = this || self,
        la = function(a) {
            return a
        };
    var ma = function() {},
        na = function(a) {
            return "function" === typeof a
        },
        k = function(a) {
            return "string" === typeof a
        },
        oa = function(a) {
            return "number" === typeof a && !isNaN(a)
        },
        pa = Array.isArray,
        ra = function(a, b) {
            if (a && pa(a))
                for (var c = 0; c < a.length; c++)
                    if (a[c] && b(a[c])) return a[c]
        },
        sa = function(a, b) {
            if (!oa(a) || !oa(b) || a > b) a = 0, b = 2147483647;
            return Math.floor(Math.random() * (b - a + 1) + a)
        },
        ua = function(a, b) {
            for (var c = new ta, d = 0; d < a.length; d++) c.set(a[d], !0);
            for (var e = 0; e < b.length; e++)
                if (c.get(b[e])) return !0;
            return !1
        },
        wa = function(a,
            b) {
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
        },
        ya = function(a) {
            return !!a && ("[object Arguments]" === Object.prototype.toString.call(a) || Object.prototype.hasOwnProperty.call(a, "callee"))
        },
        za = function(a) {
            return Math.round(Number(a)) || 0
        },
        Aa = function(a) {
            return "false" === String(a).toLowerCase() ? !1 : !!a
        },
        Ba = function(a) {
            var b = [];
            if (pa(a))
                for (var c = 0; c < a.length; c++) b.push(String(a[c]));
            return b
        },
        Ca = function(a) {
            return a ? a.replace(/^\s+|\s+$/g, "") : ""
        },
        Da = function() {
            return new Date(Date.now())
        },
        B = function() {
            return Da().getTime()
        },
        ta = function() {
            this.prefix = "gtm.";
            this.values = {}
        };
    ta.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    ta.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    var Ea = function(a, b, c) {
            return a && a.hasOwnProperty(b) ? a[b] : c
        },
        Ga = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = void 0;
                    try {
                        c()
                    } catch (d) {}
                }
            }
        },
        Ha = function(a, b) {
            for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
        },
        Ia = function(a) {
            for (var b in a)
                if (a.hasOwnProperty(b)) return !0;
            return !1
        },
        Ja = function(a, b) {
            for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
            return c
        },
        Ka = function(a, b) {
            for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
            d[e[e.length - 1]] = b;
            return c
        },
        La = /^\w{1,9}$/,
        Ma = function(a, b) {
            a = a || {};
            b = b || ",";
            var c = [];
            wa(a, function(d, e) {
                La.test(d) && e && c.push(d)
            });
            return c.join(b)
        };
    var Na, Oa = function() {
        if (void 0 === Na) {
            var a = null,
                b = ka.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: la,
                        createScript: la,
                        createScriptURL: la
                    })
                } catch (c) {
                    ka.console && ka.console.error(c.message)
                }
                Na = a
            } else Na = a
        }
        return Na
    };
    var Qa = function(a, b) {
        this.m = b === Pa ? a : ""
    };
    Qa.prototype.toString = function() {
        return this.m + ""
    };
    var Pa = {};
    var Ra = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

    function Sa() {
        var a = ka.navigator;
        if (a) {
            var b = a.userAgent;
            if (b) return b
        }
        return ""
    }

    function Ta(a) {
        return -1 != Sa().indexOf(a)
    };
    var Ua = {},
        Va = function(a, b, c) {
            this.m = c === Ua ? a : ""
        };
    Va.prototype.toString = function() {
        return this.m.toString()
    };
    var Wa = function(a) {
            return a instanceof Va && a.constructor === Va ? a.m : "type_error:SafeHtml"
        },
        Xa = function(a) {
            var b = Oa(),
                c = b ? b.createHTML(a) : a;
            return new Va(c, null, Ua)
        };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    function Ya(a) {
        if ("script" === a.tagName.toLowerCase()) throw Error("Use setTextContent with a SafeScript.");
        if ("style" === a.tagName.toLowerCase()) throw Error("Use setTextContent with a SafeStyleSheet.");
    };
    var G = window,
        H = document,
        Za = navigator,
        $a = H.currentScript && H.currentScript.src,
        ab = function(a, b) {
            var c = G[a];
            G[a] = void 0 === c ? b : c;
            return G[a]
        },
        bb = function(a, b) {
            b && (a.addEventListener ? a.onload = b : a.onreadystatechange = function() {
                a.readyState in {
                    loaded: 1,
                    complete: 1
                } && (a.onreadystatechange = null, b())
            })
        },
        cb = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        db = {
            onload: 1,
            src: 1,
            width: 1,
            height: 1,
            style: 1
        };

    function eb(a, b, c) {
        b && wa(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }
    var fb = function(a, b, c, d) {
            var e = H.createElement("script");
            eb(e, d, cb);
            e.type = "text/javascript";
            e.async = !0;
            var f, g = Oa(),
                l = g ? g.createScriptURL(a) : a;
            f = new Qa(l, Pa);
            e.src = f instanceof Qa && f.constructor === Qa ? f.m : "type_error:TrustedResourceUrl";
            var m, n, p, q = null == (p = (n = (e.ownerDocument && e.ownerDocument.defaultView || window).document).querySelector) ? void 0 : p.call(n, "script[nonce]");
            (m = q ? q.nonce || q.getAttribute("nonce") || "" : "") && e.setAttribute("nonce", m);
            bb(e, b);
            c && (e.onerror = c);
            var r = H.getElementsByTagName("script")[0] ||
                H.body || H.head;
            r.parentNode.insertBefore(e, r);
            return e
        },
        gb = function() {
            if ($a) {
                var a = $a.toLowerCase();
                if (0 === a.indexOf("https://")) return 2;
                if (0 === a.indexOf("http://")) return 3
            }
            return 1
        },
        hb = function(a, b, c, d, e) {
            var f = e,
                g = !1;
            f || (f = H.createElement("iframe"), g = !0);
            eb(f, c, db);
            d && wa(d, function(m, n) {
                f.dataset[m] = n
            });
            f.height = "0";
            f.width = "0";
            f.style.display = "none";
            f.style.visibility = "hidden";
            if (g) {
                var l = H.body && H.body.lastChild || H.body || H.head;
                l.parentNode.insertBefore(f, l)
            }
            bb(f, b);
            void 0 !== a && (f.src = a);
            return f
        },
        ib = function(a, b, c) {
            var d = new Image(1, 1);
            d.onload = function() {
                d.onload = null;
                b && b()
            };
            d.onerror = function() {
                d.onerror = null;
                c && c()
            };
            d.src = a;
            return d
        },
        jb = function(a, b, c, d) {
            a.addEventListener ? a.addEventListener(b, c, !!d) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        kb = function(a, b, c) {
            a.removeEventListener ? a.removeEventListener(b, c, !1) : a.detachEvent && a.detachEvent("on" + b, c)
        },
        J = function(a) {
            G.setTimeout(a, 0)
        },
        lb = function(a, b) {
            return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value : null
        },
        mb = function(a) {
            var b =
                a.innerText || a.textContent || "";
            b && " " != b && (b = b.replace(/^[\s\xa0]+|[\s\xa0]+$/g, ""));
            b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
            return b
        },
        nb = function(a) {
            var b = H.createElement("div"),
                c = b,
                d = Xa("A<div>" + a + "</div>");
            void 0 !== c.tagName && Ya(c);
            c.innerHTML = Wa(d);
            b = b.lastChild;
            for (var e = []; b.firstChild;) e.push(b.removeChild(b.firstChild));
            return e
        },
        ob = function(a, b, c) {
            c = c || 100;
            for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
            for (var f = a, g = 0; f && g <= c; g++) {
                if (d[String(f.tagName).toLowerCase()]) return f;
                f = f.parentElement
            }
            return null
        },
        pb = function(a) {
            var b;
            try {
                b = Za.sendBeacon && Za.sendBeacon(a)
            } catch (c) {}
            b || ib(a)
        },
        qb = function(a, b) {
            var c = a[b];
            c && "string" === typeof c.animVal && (c = c.animVal);
            return c
        },
        rb = function(a) {
            var b = H.featurePolicy;
            return b && na(b.allowsFeature) ? b.allowsFeature(a) : !1
        };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
    var sb = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        tb = function(a) {
            if (null == a) return String(a);
            var b = sb.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        ub = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        vb = function(a) {
            if (!a || "object" != tb(a) || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !ub(a, "constructor") && !ub(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return void 0 ===
                b || ub(a, b)
        },
        P = function(a, b) {
            var c = b || ("array" == tb(a) ? [] : {}),
                d;
            for (d in a)
                if (ub(a, d)) {
                    var e = a[d];
                    "array" == tb(e) ? ("array" != tb(c[d]) && (c[d] = []), c[d] = P(e, c[d])) : vb(e) ? (vb(c[d]) || (c[d] = {}), c[d] = P(e, c[d])) : c[d] = e
                }
            return c
        };
    var wb = function(a) {
        if (void 0 === a || pa(a) || vb(a)) return !0;
        switch (typeof a) {
            case "boolean":
            case "number":
            case "string":
            case "function":
                return !0
        }
        return !1
    };
    var xb = function() {
        var a = function(b) {
            return {
                toString: function() {
                    return b
                }
            }
        };
        return {
            sh: a("consent"),
            th: a("consent_always_fire"),
            vf: a("convert_case_to"),
            wf: a("convert_false_to"),
            xf: a("convert_null_to"),
            yf: a("convert_true_to"),
            zf: a("convert_undefined_to"),
            Tj: a("debug_mode_metadata"),
            tb: a("function"),
            Ge: a("instance_name"),
            ei: a("live_only"),
            fi: a("malware_disabled"),
            gi: a("metadata"),
            li: a("original_activity_id"),
            Yj: a("original_vendor_template_id"),
            Xj: a("once_on_load"),
            ki: a("once_per_event"),
            bg: a("once_per_load"),
            $j: a("priority_override"),
            bk: a("respected_consent_types"),
            fg: a("setup_tags"),
            hg: a("tag_id"),
            ig: a("teardown_tags")
        }
    }();
    var Ub;
    var Vb = [],
        Wb = [],
        Xb = [],
        Yb = [],
        Zb = [],
        $b = {},
        cc, dc, ec, fc = function(a, b) {
            var c = a["function"],
                d = b && b.event;
            if (!c) throw Error("Error: No function name given for function call.");
            var e = $b[c],
                f = {},
                g;
            for (g in a)
                if (a.hasOwnProperty(g))
                    if (0 === g.indexOf("vtp_")) e && d && d.yg && d.yg(a[g]), f[void 0 !== e ? g : g.substr(4)] = a[g];
                    else if (g === xb.th.toString() && a[g]) {}
            e && d && d.xg && (f.vtp_gtmCachedValues = d.xg);
            if (b) {
                if (null == b.name) {
                    var l;
                    a: {
                        var m = b.index;
                        if (null == m) l = "";
                        else {
                            var n;
                            switch (b.type) {
                                case 2:
                                    n = Vb[m];
                                    break;
                                case 1:
                                    n = Yb[m];
                                    break;
                                default:
                                    l = "";
                                    break a
                            }
                            var p = n && n[xb.Ge];
                            l = p ? String(p) : ""
                        }
                    }
                    b.name = l
                }
                e && (f.vtp_gtmEntityIndex = b.index, f.vtp_gtmEntityName = b.name)
            }
            return void 0 !== e ? e(f) : Ub(c, f, b)
        },
        hc = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = gc(a[e], b, c));
            return d
        },
        gc = function(a, b, c) {
            if (pa(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e <
                            a.length; e++) d.push(gc(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var g = Vb[f];
                        if (!g || b.$e(g)) return;
                        c[f] = !0;
                        var l = String(g[xb.Ge]);
                        try {
                            var m = hc(g, b, c);
                            m.vtp_gtmEventId = b.id;
                            b.priorityId && (m.vtp_gtmPriorityId = b.priorityId);
                            d = fc(m, {
                                event: b,
                                index: f,
                                type: 2,
                                name: l
                            });
                            ec && (d = ec.Bi(d, m))
                        } catch (w) {
                            b.Qg && b.Qg(w, Number(f), l), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var n = 1; n < a.length; n += 2) d[gc(a[n], b, c)] = gc(a[n + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var p = !1, q = 1; q < a.length; q++) {
                            var r = gc(a[q],
                                b, c);
                            dc && (p = p || r === dc.ud);
                            d.push(r)
                        }
                        return dc && p ? dc.Gi(d) : d.join("");
                    case "escape":
                        d = gc(a[1], b, c);
                        if (dc && pa(a[1]) && "macro" === a[1][0] && dc.aj(a)) return dc.sj(d);
                        d = String(d);
                        for (var u = 2; u < a.length; u++) yb[a[u]] && (d = yb[a[u]](d));
                        return d;
                    case "tag":
                        var t = a[1];
                        if (!Yb[t]) throw Error("Unable to resolve tag reference " + t + ".");
                        return d = {
                            Eg: a[2],
                            index: t
                        };
                    case "zb":
                        var v = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        v["function"] = a[1];
                        var y = ic(v, b, c),
                            x = !!a[4];
                        return x || 2 !== y ? x !== (1 === y) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " +
                            a[0] + ".");
                }
            }
            return a
        },
        ic = function(a, b, c) {
            try {
                return cc(hc(a, b, c))
            } catch (d) {
                JSON.stringify(a)
            }
            return 2
        };
    var lc = function(a) {
            function b(r) {
                for (var u = 0; u < r.length; u++) d[r[u]] = !0
            }
            for (var c = [], d = [], e = jc(a), f = 0; f < Wb.length; f++) {
                var g = Wb[f],
                    l = kc(g, e);
                if (l) {
                    for (var m = g.add || [], n = 0; n < m.length; n++) c[m[n]] = !0;
                    b(g.block || [])
                } else null === l && b(g.block || []);
            }
            for (var p = [], q = 0; q < Yb.length; q++) c[q] && !d[q] && (p[q] = !0);
            return p
        },
        kc = function(a, b) {
            for (var c = a["if"] || [], d = 0; d < c.length; d++) {
                var e = b(c[d]);
                if (0 === e) return !1;
                if (2 === e) return null
            }
            for (var f =
                    a.unless || [], g = 0; g < f.length; g++) {
                var l = b(f[g]);
                if (2 === l) return null;
                if (1 === l) return !1
            }
            return !0
        },
        jc = function(a) {
            var b = [];
            return function(c) {
                void 0 === b[c] && (b[c] = ic(Xb[c], a));
                return b[c]
            }
        };
    var mc = {
        Bi: function(a, b) {
            b[xb.vf] && "string" === typeof a && (a = 1 == b[xb.vf] ? a.toLowerCase() : a.toUpperCase());
            b.hasOwnProperty(xb.xf) && null === a && (a = b[xb.xf]);
            b.hasOwnProperty(xb.zf) && void 0 === a && (a = b[xb.zf]);
            b.hasOwnProperty(xb.yf) && !0 === a && (a = b[xb.yf]);
            b.hasOwnProperty(xb.wf) && !1 === a && (a = b[xb.wf]);
            return a
        }
    };


    var R = {
        sb: "_ee",
        Hc: "_syn_or_mod",
        ic: "_def",
        ck: "_uei",
        dk: "_upi",
        Qb: "_eu",
        Zj: "_pci",
        ag: "_is_passthrough_cid",
        $f: "_is_linker_valid",
        Ie: "_ntg",
        yd: "_nge",
        Mb: "event_callback",
        hd: "event_timeout",
        Ca: "gtag.config",
        Ia: "gtag.get",
        qa: "purchase",
        Jb: "refund",
        lb: "begin_checkout",
        Gb: "add_to_cart",
        Hb: "remove_from_cart",
        Ch: "view_cart",
        Bf: "add_to_wishlist",
        ra: "view_item",
        Ib: "view_promotion",
        de: "select_promotion",
        ce: "select_item",
        nb: "view_item_list",
        Af: "add_payment_info",
        Bh: "add_shipping_info",
        Ra: "value_key",
        ab: "value_callback",
        X: "allow_ad_personalization_signals",
        Cc: "restricted_data_processing",
        kc: "allow_google_signals",
        wa: "cookie_expires",
        Lb: "cookie_update",
        Dc: "session_duration",
        nd: "session_engaged_time",
        fd: "engagement_time_msec",
        Fa: "user_properties",
        U: "transport_url",
        ba: "ads_data_redaction",
        ya: "user_data",
        xc: "first_party_collection",
        D: "ad_storage",
        K: "analytics_storage",
        tf: "region",
        uf: "wait_for_update",
        va: "conversion_linker",
        Ja: "conversion_cookie_prefix",
        ia: "value",
        da: "currency",
        Vf: "trip_type",
        Z: "items",
        Mf: "passengers",
        he: "allow_custom_scripts",
        rb: "session_id",
        Rf: "quantity",
        fb: "transaction_id",
        eb: "language",
        ed: "country",
        dd: "allow_enhanced_conversions",
        ne: "aw_merchant_id",
        ke: "aw_feed_country",
        me: "aw_feed_language",
        je: "discount",
        T: "developer_id",
        Jf: "global_developer_id_string",
        Hf: "event_developer_id_string",
        od: "delivery_postal_code",
        ue: "estimated_delivery_date",
        se: "shipping",
        ye: "new_customer",
        oe: "customer_lifetime_value",
        te: "enhanced_conversions",
        jc: "page_view",
        la: "linker",
        M: "domains",
        Ob: "decorate_forms",
        Gf: "enhanced_conversions_automatic_settings",
        Jh: "auto_detection_enabled",
        we: "ga_temp_client_id",
        ee: "user_engagement",
        wh: "app_remove",
        xh: "app_store_refund",
        yh: "app_store_subscription_cancel",
        zh: "app_store_subscription_convert",
        Ah: "app_store_subscription_renew",
        Dh: "first_open",
        Eh: "first_visit",
        Fh: "in_app_purchase",
        Gh: "session_start",
        Hh: "allow_display_features",
        Qa: "campaign",
        mc: "campaign_content",
        nc: "campaign_id",
        oc: "campaign_medium",
        qc: "campaign_name",
        sc: "campaign_source",
        uc: "campaign_term",
        ja: "client_id",
        ka: "cookie_domain",
        Kb: "cookie_name",
        Za: "cookie_path",
        Ka: "cookie_flags",
        vc: "custom_map",
        ld: "groups",
        Lf: "non_interaction",
        Sa: "page_location",
        ze: "page_path",
        La: "page_referrer",
        Bc: "page_title",
        xa: "send_page_view",
        qb: "send_to",
        Ec: "session_engaged",
        wc: "euid_logged_in_state",
        Fc: "session_number",
        Zh: "tracking_id",
        hb: "url_passthrough",
        Nb: "accept_incoming",
        Ac: "url_position",
        Pf: "phone_conversion_number",
        Nf: "phone_conversion_callback",
        Of: "phone_conversion_css_class",
        Qf: "phone_conversion_options",
        Uh: "phone_conversion_ids",
        Th: "phone_conversion_country_code",
        ob: "aw_remarketing",
        ie: "aw_remarketing_only",
        fe: "gclid",
        Ih: "auid",
        Oh: "affiliation",
        Ff: "tax",
        qe: "list_name",
        Ef: "checkout_step",
        Df: "checkout_option",
        Ph: "coupon",
        Qh: "promotions",
        Ea: "user_id",
        Xh: "retoken",
        Da: "cookie_prefix",
        Cf: "disable_merchant_reported_purchases",
        Nh: "dc_natural_search",
        Mh: "dc_custom_params",
        Kf: "method",
        Yh: "search_term",
        Lh: "content_type",
        Sh: "optimize_id",
        Rh: "experiments",
        cb: "google_signals"
    };
    R.kd = "google_tld";
    R.qd = "update";
    R.ve = "firebase_id";
    R.yc = "ga_restrict_domain";
    R.gd = "event_settings";
    R.pe = "dynamic_event_settings";
    R.Pb = "user_data_settings";
    R.Tf = "screen_name";
    R.Be = "screen_resolution";
    R.pb = "_x_19";
    R.$a = "enhanced_client_id";
    R.jd = "_x_20";
    R.xe = "internal_traffic_results";
    R.pd = "traffic_type";
    R.md = "referral_exclusion_definition";
    R.zc = "ignore_referrer";
    R.Kh = "content_group";
    R.sa = "allow_interest_groups";
    R.Ae = "redact_device_info", R.If = "geo_granularity";
    var Kc = {};
    R.Yf = Object.freeze((Kc[R.Af] = 1, Kc[R.Bh] = 1, Kc[R.Gb] = 1, Kc[R.Hb] = 1, Kc[R.Ch] = 1, Kc[R.lb] = 1, Kc[R.ce] = 1, Kc[R.nb] = 1, Kc[R.de] = 1, Kc[R.Ib] = 1, Kc[R.qa] = 1, Kc[R.Jb] = 1, Kc[R.ra] = 1, Kc[R.Bf] = 1, Kc));
    R.De = Object.freeze([R.X, R.kc, R.Lb]);
    R.ii = Object.freeze([].concat(R.De));
    R.Ee = Object.freeze([R.wa, R.hd, R.Dc, R.nd, R.fd]);
    R.ji = Object.freeze([].concat(R.Ee));
    var Lc = {};
    R.ae = (Lc[R.D] = "1", Lc[R.K] = "2", Lc);
    var Nc = {
        Fi: "IN",
        zj: "IN-TG"
    };
    var Oc = {},
        Pc = function(a, b) {
            Oc[a] = Oc[a] || [];
            Oc[a][b] = !0
        },
        Qc = function(a) {
            for (var b = [], c = Oc[a] || [], d = 0; d < c.length; d++) c[d] && (b[Math.floor(d / 6)] ^= 1 << d % 6);
            for (var e = 0; e < b.length; e++) b[e] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e] || 0);
            return b.join("")
        },
        Uc = function() {
            for (var a = [], b = Oc.GA4_EVENT || [], c = 0; c < b.length; c++) b[c] && a.push(c);
            return 0 < a.length ? a : void 0
        };
    var S = function(a) {
        Pc("GTM", a)
    };
    var Vc = new function(a, b) {
        this.m = a;
        this.defaultValue = void 0 === b ? !1 : b
    }(1933);
    var Xc = function() {
        var a = Wc,
            b = "Ye";
        if (a.Ye && a.hasOwnProperty(b)) return a.Ye;
        var c = new a;
        a.Ye = c;
        a.hasOwnProperty(b);
        return c
    };
    var Wc = function() {
        var a = {};
        this.m = function() {
            var b = Vc.m,
                c = Vc.defaultValue;
            return null != a[b] ? a[b] : c
        };
        this.o = function() {
            a[Vc.m] = !0
        }
    };
    var Yc = [];

    function Zc() {
        var a = ab("google_tag_data", {});
        a.ics || (a.ics = {
            entries: {},
            set: $c,
            update: ad,
            addListener: bd,
            notifyListeners: cd,
            active: !1,
            usedDefault: !1,
            usedUpdate: !1,
            accessedDefault: !1,
            accessedAny: !1,
            wasSetLate: !1
        });
        return a.ics
    }

    function $c(a, b, c, d, e, f) {
        var g = Zc();
        g.usedDefault || !g.accessedDefault && !g.accessedAny || (g.wasSetLate = !0);
        g.active = !0;
        g.usedDefault = !0;
        if (void 0 != b) {
            var l = g.entries,
                m = l[a] || {},
                n = m.region,
                p = c && k(c) ? c.toUpperCase() : void 0;
            d = d.toUpperCase();
            e = e.toUpperCase();
            if ("" === d || p === e || (p === d ? n !== e : !p && !n)) {
                var q = !!(f && 0 < f && void 0 === m.update),
                    r = {
                        region: p,
                        initial: "granted" === b,
                        update: m.update,
                        quiet: q
                    };
                if ("" !== d || !1 !== m.initial) l[a] = r;
                q && G.setTimeout(function() {
                    l[a] === r && r.quiet && (r.quiet = !1, dd(a), cd(), Pc("TAGGING",
                        2))
                }, f)
            }
        }
    }

    function ad(a, b) {
        var c = Zc();
        c.usedDefault || c.usedUpdate || !c.accessedAny || (c.wasSetLate = !0);
        c.active = !0;
        c.usedUpdate = !0;
        if (void 0 != b) {
            var d = ed(c, a),
                e = c.entries,
                f = e[a] = e[a] || {};
            f.update = "granted" === b;
            var g = ed(c, a);
            f.quiet ? (f.quiet = !1, dd(a)) : g !== d && dd(a)
        }
    }

    function bd(a, b) {
        Yc.push({
            Se: a,
            Oi: b
        })
    }

    function dd(a) {
        for (var b = 0; b < Yc.length; ++b) {
            var c = Yc[b];
            pa(c.Se) && -1 !== c.Se.indexOf(a) && (c.Wg = !0)
        }
    }

    function cd(a, b) {
        for (var c = 0; c < Yc.length; ++c) {
            var d = Yc[c];
            if (d.Wg) {
                d.Wg = !1;
                try {
                    d.Oi({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    }

    function ed(a, b) {
        var c = a.entries[b] || {};
        return void 0 !== c.update ? c.update : c.initial
    }
    var fd = function(a) {
            var b = Zc();
            b.accessedAny = !0;
            return ed(b, a)
        },
        gd = function(a) {
            var b = Zc();
            b.accessedDefault = !0;
            return (b.entries[a] || {}).initial
        },
        hd = function(a) {
            var b = Zc();
            b.accessedAny = !0;
            return !(b.entries[a] || {}).quiet
        },
        id = function() {
            if (!Xc().m()) return !1;
            var a = Zc();
            a.accessedAny = !0;
            return a.active
        },
        jd = function() {
            var a = Zc();
            a.accessedDefault = !0;
            return a.usedDefault
        },
        kd = function(a, b) {
            Zc().addListener(a, b)
        },
        ld = function(a, b) {
            Zc().notifyListeners(a, b)
        },
        md = function(a, b) {
            function c() {
                for (var e = 0; e < b.length; e++)
                    if (!hd(b[e])) return !0;
                return !1
            }
            if (c()) {
                var d = !1;
                kd(b, function(e) {
                    d || c() || (d = !0, a(e))
                })
            } else a({})
        },
        nd = function(a, b) {
            function c() {
                for (var f = [], g = 0; g < d.length; g++) {
                    var l = d[g];
                    !1 === fd(l) || e[l] || (f.push(l), e[l] = !0)
                }
                return f
            }
            var d = k(b) ? [b] : b,
                e = {};
            c().length !== d.length && kd(d, function(f) {
                var g = c();
                0 < g.length && (f.Se = g, a(f))
            })
        };

    function od() {}

    function pd() {};

    function qd(a) {
        for (var b = [], c = 0; c < rd.length; c++) {
            var d = a(rd[c]);
            b[c] = !0 === d ? "1" : !1 === d ? "0" : "-"
        }
        return b.join("")
    }
    var rd = [R.D, R.K],
        sd = function(a) {
            var b = a[R.tf];
            b && S(40);
            var c = a[R.uf];
            c && S(41);
            for (var d = pa(b) ? b : [b], e = {
                    ac: 0
                }; e.ac < d.length; e = {
                    ac: e.ac
                }, ++e.ac) wa(a, function(f) {
                return function(g, l) {
                    if (g !== R.tf && g !== R.uf) {
                        var m = d[f.ac],
                            n = Nc.Fi,
                            p = Nc.zj;
                        Zc().set(g, l, m, n, p, c)
                    }
                }
            }(e))
        },
        td = 0,
        ud = function(a, b) {
            wa(a, function(e, f) {
                Zc().update(e, f)
            });
            ld(b.eventId, b.priorityId);
            var c = B(),
                d = c - td;
            td && 0 <= d && 1E3 > d && S(66);
            td = c
        },
        vd = function(a) {
            var b = fd(a);
            return void 0 != b ? b : !0
        },
        wd = function() {
            return "G1" + qd(fd)
        },
        xd = function(a, b) {
            nd(a,
                b)
        },
        yd = function(a, b) {
            md(a, b)
        };
    var Cd = function(a) {
            return Bd ? H.querySelectorAll(a) : null
        },
        Dd = function(a, b) {
            if (!Bd) return null;
            if (Element.prototype.closest) try {
                return a.closest(b)
            } catch (e) {
                return null
            }
            var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
                d = a;
            if (!H.documentElement.contains(d)) return null;
            do {
                try {
                    if (c.call(d, b)) return d
                } catch (e) {
                    break
                }
                d = d.parentElement || d.parentNode
            } while (null !== d && 1 === d.nodeType);
            return null
        },
        Ed = !1;
    if (H.querySelectorAll) try {
        var Fd = H.querySelectorAll(":root");
        Fd && 1 == Fd.length && Fd[0] == H.documentElement && (Ed = !0)
    } catch (a) {}
    var Bd = Ed;
    var Zd = {},
        T = G.google_tag_manager = G.google_tag_manager || {},
        $d = Math.random();
    Zd.Cd = "4k0";
    Zd.W = "dataLayer";
    Zd.vh = "ChEI8IGEkwYQ2pWvvsDakae0ARIkAAA9PlSF5/sniXHU/A/+35L3l74MmnT1wdLFT8kGQfQ27hJAGgKaNA\x3d\x3d";
    var ae = {
            __cl: !0,
            __ecl: !0,
            __ehl: !0,
            __evl: !0,
            __fal: !0,
            __fil: !0,
            __fsl: !0,
            __hl: !0,
            __jel: !0,
            __lcl: !0,
            __sdl: !0,
            __tl: !0,
            __ytl: !0
        },
        be = {
            __paused: !0,
            __tg: !0
        },
        ce;
    for (ce in ae) ae.hasOwnProperty(ce) && (be[ce] = !0);
    Zd.hc = "www.googletagmanager.com";
    var de, ee = Zd.hc + "/gtm.js";
    de = ee;
    var fe = Aa(""),
        ge = null,
        he = null,
        ie = {},
        je = {},
        ke = function() {
            var a = T.sequence || 1;
            T.sequence = a + 1;
            return a
        };
    Zd.uh = "";
    var le = "";
    Zd.Dd = le;
    var me = new ta,
        ne = {},
        oe = {},
        re = {
            name: Zd.W,
            set: function(a, b) {
                P(Ka(a, b), ne);
                pe()
            },
            get: function(a) {
                return qe(a, 2)
            },
            reset: function() {
                me = new ta;
                ne = {};
                pe()
            }
        },
        qe = function(a, b) {
            return 2 != b ? me.get(a) : se(a)
        },
        se = function(a) {
            var b, c = a.split(".");
            b = b || [];
            for (var d = ne, e = 0; e < c.length; e++) {
                if (null === d) return !1;
                if (void 0 === d) break;
                d = d[c[e]];
                if (-1 !== b.indexOf(d)) return
            }
            return d
        },
        te = function(a, b) {
            oe.hasOwnProperty(a) || (me.set(a, b), P(Ka(a, b), ne), pe())
        },
        pe = function(a) {
            wa(oe, function(b, c) {
                me.set(b, c);
                P(Ka(b), ne);
                P(Ka(b,
                    c), ne);
                a && delete oe[b]
            })
        },
        xe = function(a, b) {
            var c, d = 1 !== (void 0 === b ? 2 : b) ? se(a) : me.get(a);
            "array" === tb(d) || "object" === tb(d) ? c = P(d) : c = d;
            return c
        };
    var ye, ze = !1,
        Ae = function(a) {
            if (!ze) {
                ze = !0;
                ye = ye || {}
            }
            return ye[a]
        };
    var Be = function(a) {
        if (H.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top == b.bottom || b.left == b.right || !G.getComputedStyle) return !0;
        var c = G.getComputedStyle(a, null);
        if ("hidden" === c.visibility) return !0;
        for (var d = a, e = c; d;) {
            if ("none" === e.display) return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var l = g.indexOf("opacity(");
                0 <= l && (g = g.substring(l + 8, g.indexOf(")", l)), "%" == g.charAt(g.length - 1) && (g = g.substring(0, g.length - 1)), f = Math.min(g, f))
            }
            if (void 0 !== f && 0 >= f) return !0;
            (d = d.parentElement) && (e = G.getComputedStyle(d,
                null))
        }
        return !1
    };
    var Ke = /:[0-9]+$/,
        Le = function(a, b, c) {
            for (var d = a.split("&"), e = 0; e < d.length; e++) {
                var f = d[e].split("=");
                if (decodeURIComponent(f[0]).replace(/\+/g, " ") === b) {
                    var g = f.slice(1).join("=");
                    return c ? g : decodeURIComponent(g).replace(/\+/g, " ")
                }
            }
        },
        Oe = function(a, b, c, d, e) {
            b && (b = String(b).toLowerCase());
            if ("protocol" === b || "port" === b) a.protocol = Me(a.protocol) || Me(G.location.protocol);
            "port" === b ? a.port = String(Number(a.hostname ? a.port : G.location.port) || ("http" === a.protocol ? 80 : "https" === a.protocol ? 443 : "")) : "host" ===
                b && (a.hostname = (a.hostname || G.location.hostname).replace(Ke, "").toLowerCase());
            return Ne(a, b, c, d, e)
        },
        Ne = function(a, b, c, d, e) {
            var f, g = Me(a.protocol);
            b && (b = String(b).toLowerCase());
            switch (b) {
                case "url_no_fragment":
                    f = Pe(a);
                    break;
                case "protocol":
                    f = g;
                    break;
                case "host":
                    f = a.hostname.replace(Ke, "").toLowerCase();
                    if (c) {
                        var l = /^www\d*\./.exec(f);
                        l && l[0] && (f = f.substr(l[0].length))
                    }
                    break;
                case "port":
                    f = String(Number(a.port) || ("http" === g ? 80 : "https" === g ? 443 : ""));
                    break;
                case "path":
                    a.pathname || a.hostname || Pc("TAGGING",
                        1);
                    f = "/" === a.pathname.substr(0, 1) ? a.pathname : "/" + a.pathname;
                    var m = f.split("/");
                    0 <= (d || []).indexOf(m[m.length - 1]) && (m[m.length - 1] = "");
                    f = m.join("/");
                    break;
                case "query":
                    f = a.search.replace("?", "");
                    e && (f = Le(f, e));
                    break;
                case "extension":
                    var n = a.pathname.split(".");
                    f = 1 < n.length ? n[n.length - 1] : "";
                    f = f.split("/")[0];
                    break;
                case "fragment":
                    f = a.hash.replace("#", "");
                    break;
                default:
                    f = a && a.href
            }
            return f
        },
        Me = function(a) {
            return a ? a.replace(":", "").toLowerCase() : ""
        },
        Pe = function(a) {
            var b = "";
            if (a && a.href) {
                var c = a.href.indexOf("#");
                b = 0 > c ? a.href : a.href.substr(0, c)
            }
            return b
        },
        Qe = function(a) {
            var b = H.createElement("a");
            a && (b.href = a);
            var c = b.pathname;
            "/" !== c[0] && (a || Pc("TAGGING", 1), c = "/" + c);
            var d = b.hostname.replace(Ke, "");
            return {
                href: b.href,
                protocol: b.protocol,
                host: b.host,
                hostname: d,
                pathname: c,
                search: b.search,
                hash: b.hash,
                port: b.port
            }
        },
        Re = function(a) {
            function b(n) {
                var p = n.split("=")[0];
                return 0 > d.indexOf(p) ? n : p + "=0"
            }

            function c(n) {
                return n.split("&").map(b).filter(function(p) {
                    return void 0 !== p
                }).join("&")
            }
            var d = "gclid dclid gbraid wbraid gclaw gcldc gclha gclgf gclgb _gl".split(" "),
                e = Qe(a),
                f = a.split(/[?#]/)[0],
                g = e.search,
                l = e.hash;
            "?" === g[0] && (g = g.substring(1));
            "#" === l[0] && (l = l.substring(1));
            g = c(g);
            l = c(l);
            "" !== g && (g = "?" + g);
            "" !== l && (l = "#" + l);
            var m = "" + f + g + l;
            "/" === m[m.length - 1] && (m = m.substring(0, m.length - 1));
            return m
        };
    var Se = {};
    var lf = {},
        mf = function(a, b) {
            if (G._gtmexpgrp && G._gtmexpgrp.hasOwnProperty(a)) return G._gtmexpgrp[a];
            void 0 === lf[a] && (lf[a] = Math.floor(Math.random() * b));
            return lf[a]
        };
    var nf = function(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; 0 <= d; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = 0 !== c ? b ^ c >> 21 : b;
        return b
    };
    var of = function(a, b, c) {
        for (var d = [], e = b.split(";"), f = 0; f < e.length; f++) {
            var g = e[f].split("="),
                l = g[0].replace(/^\s*|\s*$/g, "");
            if (l && l == a) {
                var m = g.slice(1).join("=").replace(/^\s*|\s*$/g, "");
                m && c && (m = decodeURIComponent(m));
                d.push(m)
            }
        }
        return d
    };
    var pf = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        qf = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };

    function rf(a) {
        return "null" !== a.origin
    };
    var uf = function(a, b, c, d) {
            return sf(d) ? of (a, String(b || tf()), c) : []
        },
        xf = function(a, b, c, d, e) {
            if (sf(e)) {
                var f = vf(a, d, e);
                if (1 === f.length) return f[0].id;
                if (0 !== f.length) {
                    f = wf(f, function(g) {
                        return g.Kd
                    }, b);
                    if (1 === f.length) return f[0].id;
                    f = wf(f, function(g) {
                        return g.Rc
                    }, c);
                    return f[0] ? f[0].id : void 0
                }
            }
        };

    function yf(a, b, c, d) {
        var e = tf(),
            f = window;
        rf(f) && (f.document.cookie = a);
        var g = tf();
        return e != g || void 0 != c && 0 <= uf(b, g, !1, d).indexOf(c)
    }
    var Cf = function(a, b, c) {
            function d(u, t, v) {
                if (null == v) return delete g[t], u;
                g[t] = v;
                return u + "; " + t + "=" + v
            }

            function e(u, t) {
                if (null == t) return delete g[t], u;
                g[t] = !0;
                return u + "; " + t
            }
            if (!sf(c.Ua)) return 2;
            var f;
            void 0 == b ? f = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = zf(b), f = a + "=" + b);
            var g = {};
            f = d(f, "path", c.path);
            var l;
            c.expires instanceof Date ? l = c.expires.toUTCString() : null != c.expires && (l = "" + c.expires);
            f = d(f, "expires", l);
            f = d(f, "max-age", c.hk);
            f = d(f, "samesite",
                c.jk);
            c.kk && (f = e(f, "secure"));
            var m = c.domain;
            if (m && "auto" === m.toLowerCase()) {
                for (var n = Af(), p = 0; p < n.length; ++p) {
                    var q = "none" !== n[p] ? n[p] : void 0,
                        r = d(f, "domain", q);
                    r = e(r, c.flags);
                    if (!Bf(q, c.path) && yf(r, a, b, c.Ua)) return 0
                }
                return 1
            }
            m && "none" !== m.toLowerCase() && (f = d(f, "domain", m));
            f = e(f, c.flags);
            return Bf(m, c.path) ? 1 : yf(f, a, b, c.Ua) ? 0 : 1
        },
        Df = function(a, b, c) {
            null == c.path && (c.path = "/");
            c.domain || (c.domain = "auto");
            return Cf(a, b, c)
        };

    function wf(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var l = a[g],
                m = b(l);
            m === c ? d.push(l) : void 0 === f || m < f ? (e = [l], f = m) : m === f && e.push(l)
        }
        return 0 < d.length ? d : e
    }

    function vf(a, b, c) {
        for (var d = [], e = uf(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                l = g.shift();
            if (!b || -1 !== b.indexOf(l)) {
                var m = g.shift();
                m && (m = m.split("-"), d.push({
                    id: g.join("."),
                    Kd: 1 * m[0] || 1,
                    Rc: 1 * m[1] || 1
                }))
            }
        }
        return d
    }
    var zf = function(a) {
            a && 1200 < a.length && (a = a.substring(0, 1200));
            return a
        },
        Ef = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Ff = /(^|\.)doubleclick\.net$/i,
        Bf = function(a, b) {
            return Ff.test(window.document.location.hostname) || "/" === b && Ef.test(a)
        },
        tf = function() {
            return rf(window) ? window.document.cookie : ""
        },
        Af = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (4 === b.length) {
                var c = b[b.length - 1];
                if (parseInt(c, 10).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; 0 <= d; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            Ff.test(e) || Ef.test(e) || a.push("none");
            return a
        },
        sf = function(a) {
            if (!Xc().m() || !a || !id()) return !0;
            if (!hd(a)) return !1;
            var b = fd(a);
            return null == b ? !0 : !!b
        };
    var Gf = function(a) {
            var b = Math.round(2147483647 * Math.random());
            return a ? String(b ^ nf(a) & 2147483647) : String(b)
        },
        Hf = function(a) {
            return [Gf(a), Math.round(B() / 1E3)].join(".")
        },
        Kf = function(a, b, c, d, e) {
            var f = If(b);
            return xf(a, f, Jf(c), d, e)
        },
        Lf = function(a, b, c, d) {
            var e = "" + If(c),
                f = Jf(d);
            1 < f && (e += "-" + f);
            return [b, e, a].join(".")
        },
        If = function(a) {
            if (!a) return 1;
            a = 0 === a.indexOf(".") ? a.substr(1) : a;
            return a.split(".").length
        },
        Jf = function(a) {
            if (!a || "/" === a) return 1;
            "/" !== a[0] && (a = "/" + a);
            "/" !== a[a.length - 1] && (a += "/");
            return a.split("/").length -
                1
        };

    function Mf(a, b, c) {
        var d, e = Number(null != a.Ab ? a.Ab : void 0);
        0 !== e && (d = new Date((b || B()) + 1E3 * (e || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: d
        }
    };
    var Nf = ["1"],
        Of = {},
        Pf = {},
        Tf = function(a, b) {
            b = void 0 === b ? !0 : b;
            var c = Qf(a.prefix);
            if (!Of[c] && !Rf(c, a.path, a.domain) && b) {
                var d = Qf(a.prefix),
                    e = Hf();
                if (0 === Sf(d, e, a)) {
                    var f = ab("google_tag_data", {});
                    f._gcl_au ? Pc("GTM", 57) : f._gcl_au = e
                }
                Rf(c, a.path, a.domain)
            }
        };

    function Sf(a, b, c, d) {
        var e = Lf(b, "1", c.domain, c.path),
            f = Mf(c, d);
        f.Ua = "ad_storage";
        return Df(a, e, f)
    }

    function Rf(a, b, c) {
        var d = Kf(a, b, c, Nf, "ad_storage");
        if (!d) return !1;
        var e = d.split(".");
        5 === e.length ? (Of[a] = e.slice(0, 2).join("."), Pf[a] = {
            id: e.slice(2, 4).join("."),
            Og: Number(e[4]) || 0
        }) : 3 === e.length ? Pf[a] = {
            id: e.slice(0, 2).join("."),
            Og: Number(e[2]) || 0
        } : Of[a] = d;
        return !0
    }

    function Qf(a) {
        return (a || "_gcl") + "_au"
    };
    var Uf = function(a) {
        for (var b = [], c = H.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                qf: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, l) {
            return l.timestamp - g.timestamp
        });
        return b
    };

    function Vf(a, b) {
        var c = Uf(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!("1" !== f[0] || b && 3 > f.length || !b && 3 !== f.length) && Number(f[1])) {
                d[c[e].qf] || (d[c[e].qf] = []);
                var g = {
                    version: f[0],
                    timestamp: 1E3 * Number(f[1]),
                    za: f[2]
                };
                b && 3 < f.length && (g.labels = f.slice(3));
                d[c[e].qf].push(g)
            }
        }
        return d
    };

    function Wf() {
        for (var a = Xf, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function Yf() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var Xf, Zf;

    function $f(a) {
        function b(m) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = Zf[n];
                if (null != p) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return m
        }
        Xf = Xf || Yf();
        Zf = Zf || Wf();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                l = b(64);
            if (64 === l && -1 === e) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            64 != g && (c += String.fromCharCode(f << 4 & 240 | g >> 2), 64 != l && (c += String.fromCharCode(g << 6 & 192 | l)))
        }
    };
    var ag;
    var eg = function() {
            var a = bg,
                b = cg,
                c = dg(),
                d = function(g) {
                    a(g.target || g.srcElement || {})
                },
                e = function(g) {
                    b(g.target || g.srcElement || {})
                };
            if (!c.init) {
                jb(H, "mousedown", d);
                jb(H, "keyup", d);
                jb(H, "submit", e);
                var f = HTMLFormElement.prototype.submit;
                HTMLFormElement.prototype.submit = function() {
                    b(this);
                    f.call(this)
                };
                c.init = !0
            }
        },
        fg = function(a, b, c, d, e) {
            var f = {
                callback: a,
                domains: b,
                fragment: 2 === c,
                placement: c,
                forms: d,
                sameHost: e
            };
            dg().decorators.push(f)
        },
        gg = function(a, b, c) {
            for (var d = dg().decorators, e = {}, f = 0; f < d.length; ++f) {
                var g =
                    d[f],
                    l;
                if (l = !c || g.forms) a: {
                    var m = g.domains,
                        n = a,
                        p = !!g.sameHost;
                    if (m && (p || n !== H.location.hostname))
                        for (var q = 0; q < m.length; q++)
                            if (m[q] instanceof RegExp) {
                                if (m[q].test(n)) {
                                    l = !0;
                                    break a
                                }
                            } else if (0 <= n.indexOf(m[q]) || p && 0 <= m[q].indexOf(n)) {
                        l = !0;
                        break a
                    }
                    l = !1
                }
                if (l) {
                    var r = g.placement;
                    void 0 == r && (r = g.fragment ? 2 : 1);
                    r === b && Ha(e, g.callback())
                }
            }
            return e
        };

    function dg() {
        var a = ab("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var hg = /(.*?)\*(.*?)\*(.*)/,
        ig = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        jg = /^(?:www\.|m\.|amp\.)+/,
        rg = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function sg(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }
    var ug = function(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                if (void 0 !== d && d === d && null !== d && "[object Object]" !== d.toString()) {
                    b.push(c);
                    var e = b,
                        f = e.push,
                        g, l = String(d);
                    Xf = Xf || Yf();
                    Zf = Zf || Wf();
                    for (var m = [], n = 0; n < l.length; n += 3) {
                        var p = n + 1 < l.length,
                            q = n + 2 < l.length,
                            r = l.charCodeAt(n),
                            u = p ? l.charCodeAt(n + 1) : 0,
                            t = q ? l.charCodeAt(n + 2) : 0,
                            v = r >> 2,
                            y = (r & 3) << 4 | u >> 4,
                            x = (u & 15) << 2 | t >> 6,
                            w = t & 63;
                        q || (w = 64, p || (x = 64));
                        m.push(Xf[v], Xf[y], Xf[x], Xf[w])
                    }
                    g = m.join("");
                    f.call(e, g)
                }
            }
        var A = b.join("*");
        return ["1", tg(A),
            A
        ].join("*")
    };

    function tg(a, b) {
        var c = [G.navigator.userAgent, (new Date).getTimezoneOffset(), Za.userLanguage || Za.language, Math.floor(B() / 60 / 1E3) - (void 0 === b ? 0 : b), a].join("*"),
            d;
        if (!(d = ag)) {
            for (var e = Array(256), f = 0; 256 > f; f++) {
                for (var g = f, l = 0; 8 > l; l++) g = g & 1 ? g >>> 1 ^ 3988292384 : g >>> 1;
                e[f] = g
            }
            d = e
        }
        ag = d;
        for (var m = 4294967295, n = 0; n < c.length; n++) m = m >>> 8 ^ ag[(m ^ c.charCodeAt(n)) & 255];
        return ((m ^ -1) >>> 0).toString(36)
    }

    function vg() {
        return function(a) {
            var b = Qe(G.location.href),
                c = b.search.replace("?", ""),
                d = Le(c, "_gl", !0) || "";
            a.query = wg(d) || {};
            var e = Oe(b, "fragment").match(sg("_gl"));
            a.fragment = wg(e && e[3] || "") || {}
        }
    }

    function xg(a, b) {
        var c = sg(a).exec(b),
            d = b;
        if (c) {
            var e = c[2],
                f = c[4];
            d = c[1];
            f && (d = d + e + f)
        }
        return d
    }
    var yg = function(a, b) {
            b || (b = "_gl");
            var c = rg.exec(a);
            if (!c) return "";
            var d = c[1],
                e = xg(b, (c[2] || "").slice(1)),
                f = xg(b, (c[3] || "").slice(1));
            e.length && (e = "?" + e);
            f.length && (f = "#" + f);
            return "" + d + e + f
        },
        zg = function(a) {
            var b = vg(),
                c = dg();
            c.data || (c.data = {
                query: {},
                fragment: {}
            }, b(c.data));
            var d = {},
                e = c.data;
            e && (Ha(d, e.query), a && Ha(d, e.fragment));
            return d
        },
        wg = function(a) {
            try {
                var b = Ag(a, 3);
                if (void 0 !== b) {
                    for (var c = {}, d = b ? b.split("*") : [], e = 0; e + 1 < d.length; e += 2) {
                        var f = d[e],
                            g = $f(d[e + 1]);
                        c[f] = g
                    }
                    Pc("TAGGING", 6);
                    return c
                }
            } catch (l) {
                Pc("TAGGING",
                    8)
            }
        };

    function Ag(a, b) {
        if (a) {
            var c;
            a: {
                for (var d = a, e = 0; 3 > e; ++e) {
                    var f = hg.exec(d);
                    if (f) {
                        c = f;
                        break a
                    }
                    d = decodeURIComponent(d)
                }
                c = void 0
            }
            var g = c;
            if (g && "1" === g[1]) {
                var l = g[3],
                    m;
                a: {
                    for (var n = g[2], p = 0; p < b; ++p)
                        if (n === tg(l, p)) {
                            m = !0;
                            break a
                        }
                    m = !1
                }
                if (m) return l;
                Pc("TAGGING", 7)
            }
        }
    }

    function Bg(a, b, c, d) {
        function e(p) {
            p = xg(a, p);
            var q = p.charAt(p.length - 1);
            p && "&" !== q && (p += "&");
            return p + n
        }
        d = void 0 === d ? !1 : d;
        var f = rg.exec(c);
        if (!f) return "";
        var g = f[1],
            l = f[2] || "",
            m = f[3] || "",
            n = a + "=" + b;
        d ? m = "#" + e(m.substring(1)) : l = "?" + e(l.substring(1));
        return "" + g + l + m
    }

    function Cg(a, b) {
        var c = "FORM" === (a.tagName || "").toUpperCase(),
            d = gg(b, 1, c),
            e = gg(b, 2, c),
            f = gg(b, 3, c);
        if (Ia(d)) {
            var g = ug(d);
            c ? Dg("_gl", g, a) : Eg("_gl", g, a, !1)
        }
        if (!c && Ia(e)) {
            var l = ug(e);
            Eg("_gl", l, a, !0)
        }
        for (var m in f)
            if (f.hasOwnProperty(m)) a: {
                var n = m,
                    p = f[m],
                    q = a;
                if (q.tagName) {
                    if ("a" === q.tagName.toLowerCase()) {
                        Eg(n, p, q);
                        break a
                    }
                    if ("form" === q.tagName.toLowerCase()) {
                        Dg(n, p, q);
                        break a
                    }
                }
                "string" == typeof q && Bg(n, p, q)
            }
    }

    function Eg(a, b, c, d) {
        if (c.href) {
            var e = Bg(a, b, c.href, void 0 === d ? !1 : d);
            Ra.test(e) && (c.href = e)
        }
    }

    function Dg(a, b, c) {
        if (c && c.action) {
            var d = (c.method || "").toLowerCase();
            if ("get" === d) {
                for (var e = c.childNodes || [], f = !1, g = 0; g < e.length; g++) {
                    var l = e[g];
                    if (l.name === a) {
                        l.setAttribute("value", b);
                        f = !0;
                        break
                    }
                }
                if (!f) {
                    var m = H.createElement("input");
                    m.setAttribute("type", "hidden");
                    m.setAttribute("name", a);
                    m.setAttribute("value", b);
                    c.appendChild(m)
                }
            } else if ("post" === d) {
                var n = Bg(a, b, c.action);
                Ra.test(n) && (c.action = n)
            }
        }
    }

    function bg(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && 0 < d;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                "http:" !== f && "https:" !== f || Cg(e, e.hostname)
            }
        } catch (g) {}
    }

    function cg(a) {
        try {
            if (a.action) {
                var b = Oe(Qe(a.action), "host");
                Cg(a, b)
            }
        } catch (c) {}
    }
    var Fg = function(a, b, c, d) {
            eg();
            fg(a, b, "fragment" === c ? 2 : 1, !!d, !1)
        },
        Gg = function(a, b) {
            eg();
            fg(a, [Ne(G.location, "host", !0)], b, !0, !0)
        },
        Hg = function() {
            var a = H.location.hostname,
                b = ig.exec(H.referrer);
            if (!b) return !1;
            var c = b[2],
                d = b[1],
                e = "";
            if (c) {
                var f = c.split("/"),
                    g = f[1];
                e = "s" === g ? decodeURIComponent(f[2]) : decodeURIComponent(g)
            } else if (d) {
                if (0 === d.indexOf("xn--")) return !1;
                e = d.replace(/-/g, ".").replace(/\.\./g, "-")
            }
            var l = a.replace(jg, ""),
                m = e.replace(jg, ""),
                n;
            if (!(n = l === m)) {
                var p = "." + m;
                n = l.substring(l.length - p.length,
                    l.length) === p
            }
            return n
        },
        Ig = function(a, b) {
            return !1 === a ? !1 : a || b || Hg()
        };
    var Jg = {};
    var Kg = /^\w+$/,
        Lg = /^[\w-]+$/,
        Mg = {
            aw: "_aw",
            dc: "_dc",
            gf: "_gf",
            ha: "_ha",
            gp: "_gp",
            gb: "_gb"
        },
        Ng = function() {
            if (!Xc().m() || !id()) return !0;
            var a = fd("ad_storage");
            return null == a ? !0 : !!a
        },
        Og = function(a, b) {
            hd("ad_storage") ? Ng() ? a() : nd(a, "ad_storage") : b ? Pc("TAGGING", 3) : md(function() {
                Og(a, !0)
            }, ["ad_storage"])
        },
        Qg = function(a) {
            return Pg(a).map(function(b) {
                return b.za
            })
        },
        Pg = function(a) {
            var b = [];
            if (!rf(G) || !H.cookie) return b;
            var c = uf(a, H.cookie, void 0, "ad_storage");
            if (!c || 0 == c.length) return b;
            for (var d = {}, e = 0; e < c.length; d = {
                    $c: d.$c
                }, e++) {
                var f = Rg(c[e]);
                if (null != f) {
                    var g = f,
                        l = g.version;
                    d.$c = g.za;
                    var m = g.timestamp,
                        n = g.labels,
                        p = ra(b, function(q) {
                            return function(r) {
                                return r.za === q.$c
                            }
                        }(d));
                    p ? (p.timestamp = Math.max(p.timestamp, m), p.labels = Sg(p.labels, n || [])) : b.push({
                        version: l,
                        za: d.$c,
                        timestamp: m,
                        labels: n
                    })
                }
            }
            b.sort(function(q, r) {
                return r.timestamp - q.timestamp
            });
            return Tg(b)
        };

    function Sg(a, b) {
        for (var c = {}, d = [], e = 0; e < a.length; e++) c[a[e]] = !0, d.push(a[e]);
        for (var f = 0; f < b.length; f++) c[b[f]] || d.push(b[f]);
        return d
    }

    function Ug(a) {
        return a && "string" == typeof a && a.match(Kg) ? a : "_gcl"
    }
    var Wg = function() {
            var a = Qe(G.location.href),
                b = Oe(a, "query", !1, void 0, "gclid"),
                c = Oe(a, "query", !1, void 0, "gclsrc"),
                d = Oe(a, "query", !1, void 0, "wbraid"),
                e = Oe(a, "query", !1, void 0, "dclid");
            if (!b || !c || !d) {
                var f = a.hash.replace("#", "");
                b = b || Le(f, "gclid");
                c = c || Le(f, "gclsrc");
                d = d || Le(f, "wbraid")
            }
            return Vg(b, c, e, d)
        },
        Vg = function(a, b, c, d) {
            var e = {},
                f = function(g, l) {
                    e[l] || (e[l] = []);
                    e[l].push(g)
                };
            e.gclid = a;
            e.gclsrc = b;
            e.dclid = c;
            void 0 !== d && Lg.test(d) && (e.gbraid = d, f(d, "gb"));
            if (void 0 !== a && a.match(Lg)) switch (b) {
                case void 0:
                    f(a,
                        "aw");
                    break;
                case "aw.ds":
                    f(a, "aw");
                    f(a, "dc");
                    break;
                case "ds":
                    f(a, "dc");
                    break;
                case "3p.ds":
                    f(a, "dc");
                    break;
                case "gf":
                    f(a, "gf");
                    break;
                case "ha":
                    f(a, "ha")
            }
            c && f(c, "dc");
            return e
        },
        Yg = function(a) {
            var b = Wg();
            Og(function() {
                Xg(b, !1, a)
            })
        };

    function Xg(a, b, c, d, e) {
        function f(y, x) {
            var w = Zg(y, g);
            w && (Df(w, x, l), m = !0)
        }
        c = c || {};
        e = e || [];
        var g = Ug(c.prefix);
        d = d || B();
        var l = Mf(c, d, !0);
        l.Ua = "ad_storage";
        var m = !1,
            n = Math.round(d / 1E3),
            p = function(y) {
                var x = ["GCL", n, y];
                0 < e.length && x.push(e.join("."));
                return x.join(".")
            };
        a.aw && f("aw", p(a.aw[0]));
        a.dc && f("dc", p(a.dc[0]));
        a.gf && f("gf", p(a.gf[0]));
        a.ha && f("ha", p(a.ha[0]));
        a.gp && f("gp", p(a.gp[0]));
        if ((void 0 == Jg.enable_gbraid_cookie_write ? 0 : Jg.enable_gbraid_cookie_write) && !m && a.gb) {
            var q = a.gb[0],
                r = Zg("gb", g),
                u = !1;
            if (!b)
                for (var t = Pg(r), v = 0; v < t.length; v++) t[v].za === q && t[v].labels && 0 < t[v].labels.length && (u = !0);
            u || f("gb", p(q))
        }
    }
    var ah = function(a, b) {
            var c = zg(!0);
            Og(function() {
                for (var d = Ug(b.prefix), e = 0; e < a.length; ++e) {
                    var f = a[e];
                    if (void 0 !== Mg[f]) {
                        var g = Zg(f, d),
                            l = c[g];
                        if (l) {
                            var m = Math.min($g(l), B()),
                                n;
                            b: {
                                var p = m;
                                if (rf(G))
                                    for (var q = uf(g, H.cookie, void 0, "ad_storage"), r = 0; r < q.length; ++r)
                                        if ($g(q[r]) > p) {
                                            n = !0;
                                            break b
                                        }
                                n = !1
                            }
                            if (!n) {
                                var u = Mf(b, m, !0);
                                u.Ua = "ad_storage";
                                Df(g, l, u)
                            }
                        }
                    }
                }
                Xg(Vg(c.gclid, c.gclsrc), !1, b)
            })
        },
        Zg = function(a, b) {
            var c = Mg[a];
            if (void 0 !== c) return b + c
        },
        $g = function(a) {
            return 0 !== bh(a.split(".")).length ? 1E3 * (Number(a.split(".")[1]) ||
                0) : 0
        };

    function Rg(a) {
        var b = bh(a.split("."));
        return 0 === b.length ? null : {
            version: b[0],
            za: b[2],
            timestamp: 1E3 * (Number(b[1]) || 0),
            labels: b.slice(3)
        }
    }

    function bh(a) {
        return 3 > a.length || "GCL" !== a[0] && "1" !== a[0] || !/^\d+$/.test(a[1]) || !Lg.test(a[2]) ? [] : a
    }
    var ch = function(a, b, c, d, e) {
            if (pa(b) && rf(G)) {
                var f = Ug(e),
                    g = function() {
                        for (var l = {}, m = 0; m < a.length; ++m) {
                            var n = Zg(a[m], f);
                            if (n) {
                                var p = uf(n, H.cookie, void 0, "ad_storage");
                                p.length && (l[n] = p.sort()[p.length - 1])
                            }
                        }
                        return l
                    };
                Og(function() {
                    Fg(g, b, c, d)
                })
            }
        },
        Tg = function(a) {
            return a.filter(function(b) {
                return Lg.test(b.za)
            })
        },
        dh = function(a, b) {
            if (rf(G)) {
                for (var c = Ug(b.prefix), d = {}, e = 0; e < a.length; e++) Mg[a[e]] && (d[a[e]] = Mg[a[e]]);
                Og(function() {
                    wa(d, function(f, g) {
                        var l = uf(c + g, H.cookie, void 0, "ad_storage");
                        l.sort(function(u,
                            t) {
                            return $g(t) - $g(u)
                        });
                        if (l.length) {
                            var m = l[0],
                                n = $g(m),
                                p = 0 !== bh(m.split(".")).length ? m.split(".").slice(3) : [],
                                q = {},
                                r;
                            r = 0 !== bh(m.split(".")).length ? m.split(".")[2] : void 0;
                            q[f] = [r];
                            Xg(q, !0, b, n, p)
                        }
                    })
                })
            }
        };

    function eh(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }
    var fh = function(a) {
        function b(e, f, g) {
            g && (e[f] = g)
        }
        if (id()) {
            var c = Wg();
            if (eh(c, a)) {
                var d = {};
                b(d, "gclid", c.gclid);
                b(d, "dclid", c.dclid);
                b(d, "gclsrc", c.gclsrc);
                b(d, "wbraid", c.gbraid);
                Gg(function() {
                    return d
                }, 3);
                Gg(function() {
                    var e = {};
                    return e._up = "1", e
                }, 1)
            }
        }
    };

    function gh(a, b) {
        var c = Ug(b),
            d = Zg(a, c);
        if (!d) return 0;
        for (var e = Pg(d), f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function hh(a) {
        var b = 0,
            c;
        for (c in a)
            for (var d = a[c], e = 0; e < d.length; e++) b = Math.max(b, Number(d[e].timestamp));
        return b
    };
    var Bh = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        Ch = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        Dh = {
            cl: ["ecl"],
            customPixels: ["customScripts", "html"],
            ecl: ["cl"],
            ehl: ["hl"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        Eh = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
    var Fh = function() {
            var a = !1;
            return a
        },
        Hh = function(a) {
            var b = qe("gtm.allowlist") || qe("gtm.whitelist");
            b && S(9);
            Fh() && (b = ["google", "gtagfl", "lcl", "zone"]);
            var c = b && Ja(Ba(b), Ch),
                d = qe("gtm.blocklist") ||
                qe("gtm.blacklist");
            d || (d = qe("tagTypeBlacklist")) && S(3);
            d ? S(8) : d = [];
            Gh() && (d = Ba(d), d.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
            0 <= Ba(d).indexOf("google") && S(2);
            var e = d && Ja(Ba(d), Dh),
                f = {};
            return function(g) {
                var l = g && g[xb.tb];
                if (!l || "string" != typeof l) return !0;
                l = l.replace(/^_*/, "");
                if (void 0 !== f[l]) return f[l];
                var m = je[l] || [],
                    n = a(l, m);
                if (b) {
                    var p;
                    if (p = n) a: {
                        if (0 > c.indexOf(l))
                            if (m && 0 < m.length)
                                for (var q = 0; q < m.length; q++) {
                                    if (0 > c.indexOf(m[q])) {
                                        S(11);
                                        p = !1;
                                        break a
                                    }
                                } else {
                                    p = !1;
                                    break a
                                }
                        p = !0
                    }
                    n = p
                }
                var r = !1;
                if (d) {
                    var u = 0 <= e.indexOf(l);
                    if (u) r = u;
                    else {
                        var t = ua(e, m || []);
                        t && S(10);
                        r = t
                    }
                }
                var v = !n || r;
                v || !(0 <= m.indexOf("sandboxedScripts")) || c && -1 !== c.indexOf("sandboxedScripts") || (v = ua(e, Eh));
                return f[l] = v
            }
        },
        Gh = function() {
            return Bh.test(G.location && G.location.hostname)
        };
    var Ih = {
            H: "GTM-MSX4T79",
            fc: ""
        },
        Jh = {
            Ug: "GTM-MSX4T79",
            Vg: "GTM-MSX4T79"
        },
        Kh = function() {
            var a = [Ih.H];
            return a
        },
        Lh = function() {
            var a = [];
            Jh.Vg && (a = Jh.Vg.split("|"));
            return a
        };
    var Nh = function() {
            var a = T.tidr;
            a || (a = new Mh, T.tidr = a);
            return a
        },
        Mh = function() {
            this.container = {};
            this.destination = {};
            this.canonical = {}
        },
        Oh = function(a) {
            return Nh().container.hasOwnProperty(a)
        };
    var Rh = function(a) {},
        Vh = function(a) {},
        Wh =
        function() {
            return "&tc=" + Yb.filter(function(a) {
                return a
            }).length
        },
        Zh = function() {
            2022 <= Xh().length && Yh()
        },
        $h = function(a) {
            return 0 === a.indexOf("gtm.") ? encodeURIComponent(a) : "*"
        },
        bi = function() {
            ai || (ai = G.setTimeout(Yh, 500))
        },
        Yh = function() {
            ai && (G.clearTimeout(ai), ai = void 0);
            if (void 0 !== ci && (!di[ci] || ei || fi))
                if (gi[ci] || hi.bj() || 0 >= ii--) S(1), gi[ci] = !0;
                else {
                    hi.Aj();
                    var a = Xh(!0);
                    ib(a);
                    di[ci] = !0;
                    ki = ji = mi = ni = oi = fi = ei = "";
                    li = []
                }
        },
        Xh = function(a) {
            var b = ci;
            if (void 0 === b) return "";
            var c = Qc("GTM"),
                d = Qc("TAGGING");
            return [pi, di[b] ? "" : "&es=1", qi[b], Rh(b), c ? "&u=" + c : "", d ? "&ut=" + d : "", Wh(), ei, fi, oi, ni, Vh(a), mi, ji, ki ? "&dl=" + encodeURIComponent(ki) : "", 0 < li.length ? "&tdp=" + li.join(".") : "", "&z=0"].join("")
        },
        si = function() {
            pi = ri()
        },
        ri = function() {
            return [ti, "&v=3&t=t", "&pid=" +
                sa(), "&rv=" + Zd.Cd
            ].join("")
        },
        Uh = ["L", "S", "Y"],
        Qh = ["S", "E"],
        ui = {
            sampleRate: "0.005000",
            oh: "",
            nh: Number("5")
        },
        vi = 0 <= H.location.search.indexOf("?gtm_latency=") || 0 <= H.location.search.indexOf("&gtm_latency="),
        wi;
    if (!(wi = vi)) {
        var xi = Math.random(),
            yi = ui.sampleRate;
        wi = xi < yi
    }
    var zi =
        wi,
        ti = "https://www.googletagmanager.com/a?id=" + Ih.H + "&cv=3",
        Ai = {
            label: Ih.H + " Container",
            children: [{
                label: "Initialization",
                children: []
            }]
        },
        pi = ri(),
        di = {},
        ei = "",
        fi = "",
        mi = "",
        ni = "",
        ji = "",
        li = [],
        ki = "",
        Th = {},
        Sh = !1,
        Ph = {},
        Bi = {},
        oi = "",
        ci = void 0,
        qi = {},
        gi = {},
        ai = void 0,
        Ci = 5;
    0 < ui.nh && (Ci = ui.nh);
    var hi = function(a, b) {
            for (var c = 0, d = [], e = 0; e < a; ++e) d.push(0);
            return {
                bj: function() {
                    return c < a ? !1 : B() - d[c % a] < b
                },
                Aj: function() {
                    var f = c++ % a;
                    d[f] = B()
                }
            }
        }(Ci, 1E3),
        ii = 1E3,
        Ei = function(a, b) {
            if (zi && !gi[a] && ci !== a) {
                Yh();
                ci = a;
                mi = ei = "";
                qi[a] = "&e=" + $h(b) + "&eid=" + a;
                bi();
            }
        },
        Fi = function(a, b, c, d) {
            if (zi && b) {
                var e, f = String(b[xb.tb] || "").replace(/_/g, "");
                0 === f.indexOf("cvt") && (f = "cvt");
                e = f;
                var g = c + e;
                if (!gi[a]) {
                    a !== ci && (Yh(), ci = a);
                    ei = ei ? ei + "." + g : "&tr=" + g;
                    var l = b["function"];
                    if (!l) throw Error("Error: No function name given for function call.");
                    var m = ($b[l] ? "1" : "2") + e;
                    mi = mi ? mi + "." + m : "&ti=" + m;
                    bi();
                    Zh()
                }
            }
        };
    var Mi = function(a, b, c) {
            if (zi && !gi[a]) {
                a !== ci && (Yh(), ci = a);
                var d = c + b;
                fi = fi ? fi + "." + d : "&epr=" + d;
                bi();
                Zh()
            }
        },
        Ni = function(a, b, c) {};
    var Oi = {
            initialized: 11,
            complete: 12,
            interactive: 13
        },
        Pi = {},
        Qi = Object.freeze((Pi[R.sb] = !0, Pi[R.Hc] = !0, Pi)),
        Ri = {},
        Si = Object.freeze((Ri[R.xa] = !0, Ri)),
        Ti = 0 <= H.location.search.indexOf("?gtm_diagnostics=") || 0 <= H.location.search.indexOf("&gtm_diagnostics="),
        Vi = function(a, b, c) {};

    function Wi(a, b) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
        for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
        return c
    }

    function Ui(a, b, c, d) {
        c = void 0 === c ? {} : c;
        d = void 0 === d ? "" : d;
        if (a === b) return [];
        var e = function(q, r) {
                var u = r[q];
                return void 0 === u ? Si[q] : u
            },
            f;
        for (f in Wi(a, b))
            if (!Qi[f]) {
                var g = (d ? d + "." : "") + f,
                    l = e(f, a),
                    m = e(f, b),
                    n = "object" === tb(l) || "array" === tb(l),
                    p = "object" === tb(m) || "array" === tb(m);
                if (n && p) Ui(l, m, c, g);
                else if (n || p || l !== m) c[g] = !0
            }
        return Object.keys(c)
    };
    var Xi = !1,
        Yi = 0,
        Zi = [];

    function $i(a) {
        if (!Xi) {
            var b = H.createEventObject,
                c = "complete" == H.readyState,
                d = "interactive" == H.readyState;
            if (!a || "readystatechange" != a.type || c || !b && d) {
                Xi = !0;
                for (var e = 0; e < Zi.length; e++) J(Zi[e])
            }
            Zi.push = function() {
                for (var f = 0; f < arguments.length; f++) J(arguments[f]);
                return 0
            }
        }
    }

    function aj() {
        if (!Xi && 140 > Yi) {
            Yi++;
            try {
                H.documentElement.doScroll("left"), $i()
            } catch (a) {
                G.setTimeout(aj, 50)
            }
        }
    }
    var bj = function(a) {
        Xi ? a() : Zi.push(a)
    };
    var cj = function(a, b) {
        return {
            entityType: 1,
            indexInOriginContainer: a,
            nameInOriginContainer: b,
            originContainerId: Ih.H
        }
    };
    var ej = function(a, b) {
            this.m = !1;
            this.C = [];
            this.I = {
                tags: []
            };
            this.V = !1;
            this.o = this.s = 0;
            dj(this, a, b)
        },
        fj = function(a, b, c, d) {
            if (be.hasOwnProperty(b) || "__zone" === b) return -1;
            var e = {};
            vb(d) && (e = P(d, e));
            e.id = c;
            e.status = "timeout";
            return a.I.tags.push(e) - 1
        },
        gj = function(a, b, c, d) {
            var e = a.I.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        hj = function(a) {
            if (!a.m) {
                for (var b = a.C, c = 0; c < b.length; c++) b[c]();
                a.m = !0;
                a.C.length = 0
            }
        },
        dj = function(a, b, c) {
            void 0 !== b && ij(a, b);
            c && G.setTimeout(function() {
                return hj(a)
            }, Number(c))
        },
        ij =
        function(a, b) {
            var c = Ga(function() {
                return J(function() {
                    b(Ih.H, a.I)
                })
            });
            a.m ? c() : a.C.push(c)
        },
        jj = function(a) {
            a.s++;
            return Ga(function() {
                a.o++;
                a.V && a.o >= a.s && hj(a)
            })
        },
        kj = function(a) {
            a.V = !0;
            a.o >= a.s && hj(a)
        };
    var lj = function() {
            function a(d) {
                return !oa(d) || 0 > d ? 0 : d
            }
            if (!T._li && G.performance && G.performance.timing) {
                var b = G.performance.timing.navigationStart,
                    c = oa(re.get("gtm.start")) ? re.get("gtm.start") : 0;
                T._li = {
                    cst: a(c - b),
                    cbt: a(he - b)
                }
            }
        },
        Cj = function(a) {
            G.performance && G.performance.mark(Ih.H + "_" + a + "_start")
        },
        Dj = function(a) {
            if (G.performance) {
                var b = Ih.H + "_" + a + "_start",
                    c = Ih.H + "_" + a + "_duration";
                G.performance.measure(c, b);
                var d = G.performance.getEntriesByName(c)[0];
                G.performance.clearMarks(b);
                G.performance.clearMeasures(c);
                var e = T._p || {};
                void 0 === e[a] && (e[a] = d.duration, T._p = e);
                return d.duration
            }
        },
        Ej = function() {
            if (G.performance && G.performance.now) {
                var a = T._p || {};
                a.PAGEVIEW = G.performance.now();
                T._p = a
            }
        };
    var Fj = {},
        Gj = function() {
            return G.GoogleAnalyticsObject && G[G.GoogleAnalyticsObject]
        },
        Hj = !1;
    var Ij = function(a) {
            G.GoogleAnalyticsObject || (G.GoogleAnalyticsObject = a || "ga");
            var b = G.GoogleAnalyticsObject;
            if (G[b]) G.hasOwnProperty(b) || S(12);
            else {
                var c = function() {
                    c.q = c.q || [];
                    c.q.push(arguments)
                };
                c.l = Number(Da());
                G[b] = c
            }
            lj();
            return G[b]
        },
        Jj = function(a) {
            if (id()) {
                var b = Gj();
                b(a + "require", "linker");
                b(a + "linker:passthrough", !0)
            }
        };

    function Kj() {
        return G.GoogleAnalyticsObject || "ga"
    }
    var Lj = function(a) {},
        Mj = function(a, b) {
            return function() {
                var c = Gj(),
                    d = c && c.getByName && c.getByName(a);
                if (d) {
                    var e = d.get("sendHitTask");
                    d.set("sendHitTask", function(f) {
                        var g = f.get("hitPayload"),
                            l = f.get("hitCallback"),
                            m = 0 > g.indexOf("&tid=" + b);
                        m && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                        e(f);
                        m && (f.set("hitPayload",
                            g, !0), f.set("hitCallback", l, !0), f.set("_x_19", void 0, !0), e(f))
                    })
                }
            }
        };

    function Rj(a, b, c, d) {
        var e = Yb[a],
            f = Sj(a, b, c, d);
        if (!f) return null;
        var g = gc(e[xb.fg], c, []);
        if (g && g.length) {
            var l = g[0];
            f = Rj(l.index, {
                onSuccess: f,
                onFailure: 1 === l.Eg ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function Sj(a, b, c, d) {
        function e() {
            if (f[xb.fi]) l();
            else {
                var y = hc(f, c, []);
                var x = y[xb.sh];
                if (null != x)
                    for (var w = 0; w < x.length; w++)
                        if (!vd(x[w])) {
                            l();
                            return
                        }
                var A = fj(c.ub, String(f[xb.tb]), Number(f[xb.hg]), y[xb.gi]),
                    z = !1;
                y.vtp_gtmOnSuccess = function() {
                    if (!z) {
                        z = !0;
                        var E = B() - C;
                        Fi(c.id, Yb[a], "5", E);
                        gj(c.ub, A, "success",
                            E);
                        g()
                    }
                };
                y.vtp_gtmOnFailure = function() {
                    if (!z) {
                        z = !0;
                        var E = B() - C;
                        Fi(c.id, Yb[a], "6", E);
                        gj(c.ub, A, "failure", E);
                        l()
                    }
                };
                y.vtp_gtmTagId = f.tag_id;
                y.vtp_gtmEventId = c.id;
                c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
                Fi(c.id, f, "1");
                var D = function() {
                    var E = B() - C;
                    Fi(c.id, f, "7", E);
                    gj(c.ub, A, "exception",
                        E);
                    z || (z = !0, l())
                };
                var C = B();
                try {
                    fc(y, {
                        event: c,
                        index: a,
                        type: 1
                    })
                } catch (E) {
                    D(E)
                }
            }
        }
        var f = Yb[a],
            g = b.onSuccess,
            l = b.onFailure,
            m = b.terminate;
        if (c.$e(f)) return null;
        var n = gc(f[xb.ig], c, []);
        if (n && n.length) {
            var p = n[0],
                q = Rj(p.index, {
                    onSuccess: g,
                    onFailure: l,
                    terminate: m
                }, c, d);
            if (!q) return null;
            g = q;
            l = 2 === p.Eg ? m : q
        }
        if (f[xb.bg] || f[xb.ki]) {
            var r = f[xb.bg] ? Zb : c.Nj,
                u = g,
                t = l;
            if (!r[a]) {
                e = Ga(e);
                var v = Tj(a, r, e);
                g = v.onSuccess;
                l = v.onFailure
            }
            return function() {
                r[a](u, t)
            }
        }
        return e
    }

    function Tj(a, b, c) {
        var d = [],
            e = [];
        b[a] = Uj(d, e, c);
        return {
            onSuccess: function() {
                b[a] = Vj;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = Wj;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function Uj(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function Vj(a) {
        a()
    }

    function Wj(a, b) {
        b()
    };

    function Xj(a, b) {
        if (a) {
            var c = "" + a;
            0 !== c.indexOf("http://") && 0 !== c.indexOf("https://") && (c = "https://" + c);
            "/" === c[c.length - 1] && (c = c.substring(0, c.length - 1));
            return Qe("" + c + b).href
        }
    }

    function Yj(a, b) {
        return Zj() ? Xj(a, b) : void 0
    }

    function Zj() {
        var a = !1;
        return a
    }

    function ak() {
        return !!Zd.Dd && "SGTM_TOKEN" !== Zd.Dd.replaceAll("@@", "")
    };
    var bk = function() {
        var a = !1;
        return a
    };
    var dk = function(a, b, c, d) {
            return (2 === ck() || d || "http:" != G.location.protocol ? a : b) + c
        },
        ck = function() {
            var a = gb(),
                b;
            if (1 === a) a: {
                var c = de;c = c.toLowerCase();
                for (var d = "https://" + c, e = "http://" + c, f = 1, g = H.getElementsByTagName("script"), l = 0; l < g.length && 100 > l; l++) {
                    var m = g[l].src;
                    if (m) {
                        m = m.toLowerCase();
                        if (0 === m.indexOf(e)) {
                            b = 3;
                            break a
                        }
                        1 === f && 0 === m.indexOf(d) && (f = 2)
                    }
                }
                b = f
            }
            else b = a;
            return b
        };
    var ek = !1;
    var gk = function(a, b, c) {
            if (!fk()) {
                if (Oh(a)) return;
                var d = c ? "/gtag/js" : "/gtm.js",
                    e = "?id=" + encodeURIComponent(a) + "&l=" + Zd.W,
                    f = 0 === a.indexOf("GTM-");
                f || (e += "&cx=c");
                var g = ak();
                g && (e += "&sign=" + Zd.Dd);
                var l = Yj(b, d + e);
                if (!l) {
                    var m = Zd.hc + d;
                    g && $a && f && (m = $a.replace(/^(?:https?:\/\/)?/i,
                        "").split(/[?#]/)[0]);
                    l = dk("https://", "http://", m + e)
                }
                Nh().container[a] = !0;
                fb(l)
            }
        },
        hk = function(a, b) {
            if (!ek) gk(a, b, !0);
            else if (!fk()) {
                if (Nh().destination.hasOwnProperty(a)) return;
                var c = "/gtag/destination?id=" + encodeURIComponent(a) + "&l=" + Zd.W + "&cx=c";
                ak() && (c += "&sign=" + Zd.Dd);
                var d = Yj(b, c);
                d || (d = dk("https://", "http://", Zd.hc + c));
                Nh().destination[a] = !0;
                fb(d)
            }
        };

    function fk() {
        if (bk()) {
            return !0
        }
        return !1
    }
    var ik = function() {
            this.eventModel = {};
            this.targetConfig = {};
            this.containerConfig = {};
            this.globalConfig = {};
            this.dataLayerConfig = {};
            this.remoteConfig = {};
            this.onSuccess = function() {};
            this.onFailure = function() {};
            this.setContainerTypeLoaded = function() {};
            this.getContainerTypeLoaded = function() {};
            this.priorityId = this.eventId = void 0;
            this.isGtmEvent = !1
        },
        jk = function(a) {
            var b = new ik;
            b.eventModel = a;
            return b
        },
        kk = function(a, b) {
            a.targetConfig = b;
            return a
        },
        lk = function(a, b) {
            a.containerConfig = b;
            return a
        },
        mk = function(a, b) {
            a.globalConfig =
                b;
            return a
        },
        nk = function(a, b) {
            a.dataLayerConfig = b;
            return a
        },
        ok = function(a, b) {
            a.remoteConfig = b;
            return a
        },
        pk = function(a, b) {
            a.onSuccess = b;
            return a
        },
        qk = function(a, b) {
            a.setContainerTypeLoaded = b;
            return a
        },
        rk = function(a, b) {
            a.getContainerTypeLoaded = b;
            return a
        },
        sk = function(a, b) {
            a.onFailure = b;
            return a
        };
    h = ik.prototype;
    h.getWithConfig = function(a) {
        if (void 0 !== this.eventModel[a]) return this.eventModel[a];
        if (void 0 !== this.targetConfig[a]) return this.targetConfig[a];
        if (void 0 !== this.containerConfig[a]) return this.containerConfig[a];
        tk(this, this.globalConfig[a], this.dataLayerConfig[a]) && S(71);
        if (void 0 !== this.globalConfig[a]) return this.globalConfig[a];
        if (void 0 !== this.remoteConfig[a]) return this.remoteConfig[a]
    };
    h.getTopLevelKeys = function() {
        function a(e) {
            for (var f = Object.keys(e), g = 0; g < f.length; ++g) b[f[g]] = 1
        }
        var b = {};
        a(this.eventModel);
        a(this.targetConfig);
        a(this.containerConfig);
        a(this.globalConfig);
        for (var c = Object.keys(this.dataLayerConfig), d = 0; d < c.length; d++)
            if ("event" !== c[d] && "gtm" !== c[d] && !b.hasOwnProperty(c[d])) {
                S(71);
                break
            }
        return Object.keys(b)
    };
    h.getMergedValues = function(a, b) {
        function c(l) {
            vb(l) && wa(l, function(m, n) {
                e = !0;
                d[m] = n
            })
        }
        var d = {},
            e = !1;
        b && 1 !== b || (c(this.remoteConfig[a]), c(this.globalConfig[a]), c(this.containerConfig[a]), c(this.targetConfig[a]));
        b && 2 !== b || c(this.eventModel[a]);
        var f = e,
            g = d;
        d = {};
        e = !1;
        b && 1 !== b || (c(this.remoteConfig[a]), c(this.dataLayerConfig[a]), c(this.containerConfig[a]), c(this.targetConfig[a]));
        b && 2 !== b || c(this.eventModel[a]);
        (e !== f || tk(this, d, g)) && S(71);
        e = f;
        d = g;
        return e ? d : void 0
    };
    h.getKeysFromFirstOfAnyScope = function(a) {
        var b = {},
            c = !1,
            d = function(g) {
                for (var l = 0; l < a.length; l++) void 0 !== g[a[l]] && (b[a[l]] = g[a[l]], c = !0);
                return c
            };
        if (d(this.eventModel) || d(this.targetConfig) || d(this.containerConfig)) return b;
        d(this.globalConfig);
        var e = b,
            f = c;
        b = {};
        c = !1;
        d(this.dataLayerConfig);
        tk(this, b, e) && S(71);
        b = e;
        c = f;
        if (c) return b;
        d(this.remoteConfig);
        return b
    };
    h.getEventModelKeys = function() {
        var a = [],
            b;
        for (b in this.eventModel) b !== R.sb && this.eventModel.hasOwnProperty(b) && void 0 !== this.eventModel[b] && a.push(b);
        return a
    };
    var tk = function(a, b, c) {
        try {
            if (b === c) return !1;
            var d = tb(b);
            if (d !== tb(c) || !(vb(b) && vb(c) || "array" === d)) return !0;
            if ("array" === d) {
                if (b.length !== c.length) return !0;
                for (var e = 0; e < b.length; e++)
                    if (tk(a, b[e], c[e])) return !0
            } else {
                for (var f in c)
                    if (!b.hasOwnProperty(f)) return !0;
                for (var g in b)
                    if (!c.hasOwnProperty(g) || tk(a, b[g], c[g])) return !0
            }
        } catch (l) {
            S(72)
        }
        return !1
    };
    var uk = function() {
        T.dedupe_gclid || (T.dedupe_gclid = "" + Hf());
        return T.dedupe_gclid
    };
    var vk;
    if (3 === Zd.Cd.length) vk = "g";
    else {
        var wk = "G";
        vk = wk
    }
    var xk = {
            "": "n",
            UA: "u",
            AW: "a",
            DC: "d",
            G: "e",
            GF: "f",
            HA: "h",
            GTM: vk,
            OPT: "o"
        },
        yk = function(a) {
            var b = Ih.H.split("-"),
                c = b[0].toUpperCase(),
                d = xk[c] || "i",
                e = a && "GTM" === c ? b[1] : "OPT" === c ? b[1] : "",
                f;
            if (3 === Zd.Cd.length) {
                var g = "w";
                f = "2" + g
            } else f = "";
            return f + d + Zd.Cd + e
        };

    function zk(a, b) {
        if ("" === a) return b;
        var c = Number(a);
        return isNaN(c) ? b : c
    };
    var Ak = function(a, b) {
        a.addEventListener && a.addEventListener.call(a, "message", b, !1)
    };

    function Bk() {
        return Ta("iPhone") && !Ta("iPod") && !Ta("iPad")
    };
    Ta("Opera");
    Ta("Trident") || Ta("MSIE");
    Ta("Edge");
    !Ta("Gecko") || -1 != Sa().toLowerCase().indexOf("webkit") && !Ta("Edge") || Ta("Trident") || Ta("MSIE") || Ta("Edge"); - 1 != Sa().toLowerCase().indexOf("webkit") && !Ta("Edge") && Ta("Mobile");
    Ta("Macintosh");
    Ta("Windows");
    Ta("Linux") || Ta("CrOS");
    var Ck = ka.navigator || null;
    Ck && (Ck.appVersion || "").indexOf("X11");
    Ta("Android");
    Bk();
    Ta("iPad");
    Ta("iPod");
    Bk() || Ta("iPad") || Ta("iPod");
    Sa().toLowerCase().indexOf("kaios");
    var Dk = function(a) {
        if (!a || !H.head) return null;
        var b, c;
        c = void 0 === c ? document : c;
        b = c.createElement("meta");
        H.head.appendChild(b);
        b.httpEquiv = "origin-trial";
        b.content = a;
        return b
    };
    var Ek = function() {};
    var Fk = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        Gk = function(a, b) {
            this.o = a;
            this.m = null;
            this.C = {};
            this.V = 0;
            this.I = void 0 === b ? 500 : b;
            this.s = null
        };
    ja(Gk, Ek);
    Gk.prototype.addEventListener = function(a) {
        var b = {},
            c = qf(function() {
                return a(b)
            }),
            d = 0; - 1 !== this.I && (d = setTimeout(function() {
            b.tcString = "tcunavailable";
            b.internalErrorState = 1;
            c()
        }, this.I));
        var e = function(f, g) {
            clearTimeout(d);
            f ? (b = f, b.internalErrorState = Fk(b), g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
            a(b)
        };
        try {
            Hk(this, "addEventListener", e)
        } catch (f) {
            b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d),
                d = 0), c()
        }
    };
    Gk.prototype.removeEventListener = function(a) {
        a && a.listenerId && Hk(this, "removeEventListener", null, a.listenerId)
    };
    var Jk = function(a, b, c) {
            var d;
            d = void 0 === d ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (void 0 !== f) {
                        e = f[void 0 === d ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (0 === g) return !1;
            var l = c;
            2 === c ? (l = 0, 2 === g && (l = 1)) : 3 === c && (l = 1, 1 === g && (l = 0));
            var m;
            if (0 === l)
                if (a.purpose && a.vendor) {
                    var n = Ik(a.vendor.consents, void 0 === d ? "755" : d);
                    m = n && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? !0 : n && Ik(a.purpose.consents, b)
                } else m = !0;
            else m = 1 === l ? a.purpose && a.vendor ? Ik(a.purpose.legitimateInterests,
                b) && Ik(a.vendor.legitimateInterests, void 0 === d ? "755" : d) : !0 : !0;
            return m
        },
        Ik = function(a, b) {
            return !(!a || !a[b])
        },
        Hk = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.o.__tcfapi) {
                var e = a.o.__tcfapi;
                e(b, 2, c, d)
            } else if (Kk(a)) {
                Lk(a);
                var f = ++a.V;
                a.C[f] = c;
                if (a.m) {
                    var g = {};
                    a.m.postMessage((g.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: f,
                        parameter: d
                    }, g), "*")
                }
            } else c({}, !1)
        },
        Kk = function(a) {
            if (a.m) return a.m;
            var b;
            a: {
                for (var c = a.o, d = 0; 50 > d; ++d) {
                    var e;
                    try {
                        e = !(!c.frames || !c.frames.__tcfapiLocator)
                    } catch (l) {
                        e = !1
                    }
                    if (e) {
                        b = c;
                        break a
                    }
                    var f;
                    b: {
                        try {
                            var g = c.parent;
                            if (g && g != c) {
                                f = g;
                                break b
                            }
                        } catch (l) {}
                        f = null
                    }
                    if (!(c = f)) break
                }
                b = null
            }
            a.m = b;
            return a.m
        },
        Lk = function(a) {
            a.s || (a.s = function(b) {
                try {
                    var c;
                    c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.C[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, Ak(a.o, a.s))
        };
    var Mk = !0;
    Mk = !1;
    var Nk = {
            1: 0,
            3: 0,
            4: 0,
            7: 3,
            9: 3,
            10: 3
        },
        Ok = zk("", 550),
        Pk = zk("", 500);

    function Qk() {
        var a = T.tcf || {};
        return T.tcf = a
    }
    var Vk = function() {
        var a = Qk(),
            b = new Gk(G, Mk ? 3E3 : -1);
        if (!0 === G.gtag_enable_tcf_support && !a.active && ("function" === typeof G.__tcfapi || "function" === typeof b.o.__tcfapi || null != Kk(b))) {
            a.active = !0;
            a.Tc = {};
            Rk();
            var c = null;
            Mk ? c = G.setTimeout(function() {
                Sk(a);
                Tk(a);
                c = null
            }, Pk) : a.tcString = "tcunavailable";
            try {
                b.addEventListener(function(d) {
                    c && (clearTimeout(c), c = null);
                    if (0 !== d.internalErrorState) Sk(a), Tk(a);
                    else {
                        var e;
                        a.gdprApplies = d.gdprApplies;
                        if (!1 === d.gdprApplies) e = Uk(), b.removeEventListener(d);
                        else if ("tcloaded" ===
                            d.eventStatus || "useractioncomplete" === d.eventStatus || "cmpuishown" === d.eventStatus) {
                            var f = {},
                                g;
                            for (g in Nk)
                                if (Nk.hasOwnProperty(g))
                                    if ("1" === g) {
                                        var l = d,
                                            m = !0;
                                        m = void 0 === m ? !1 : m;
                                        var n;
                                        var p = l;
                                        !1 === p.gdprApplies ? n = !0 : (void 0 === p.internalErrorState && (p.internalErrorState = Fk(p)), n = "error" === p.cmpStatus || 0 !== p.internalErrorState || "loaded" === p.cmpStatus && ("tcloaded" === p.eventStatus || "useractioncomplete" === p.eventStatus) ? !0 : !1);
                                        f["1"] = n ? !1 === l.gdprApplies || "tcunavailable" === l.tcString || void 0 === l.gdprApplies &&
                                            !m || "string" !== typeof l.tcString || !l.tcString.length ? !0 : Jk(l, "1", 0) : !1
                                    } else f[g] = Jk(d, g, Nk[g]);
                            e = f
                        }
                        e && (a.tcString = d.tcString || "tcempty", a.Tc = e, Tk(a))
                    }
                })
            } catch (d) {
                c && (clearTimeout(c), c = null), Sk(a), Tk(a)
            }
        }
    };

    function Sk(a) {
        a.type = "e";
        a.tcString = "tcunavailable";
        Mk && (a.Tc = Uk())
    }

    function Rk() {
        var a = {},
            b = (a.ad_storage = "denied", a.wait_for_update = Ok, a);
        sd(b)
    }

    function Uk() {
        var a = {},
            b;
        for (b in Nk) Nk.hasOwnProperty(b) && (a[b] = !0);
        return a
    }

    function Tk(a) {
        var b = {},
            c = (b.ad_storage = a.Tc["1"] ? "granted" : "denied", b);
        ud(c, {
            eventId: 0
        }, {
            gdprApplies: a ? a.gdprApplies : void 0,
            tcString: Wk()
        })
    }
    var Wk = function() {
            var a = Qk();
            return a.active ? a.tcString || "" : ""
        },
        Xk = function() {
            var a = Qk();
            return a.active && void 0 !== a.gdprApplies ? a.gdprApplies ? "1" : "0" : ""
        },
        Yk = function(a) {
            if (!Nk.hasOwnProperty(String(a))) return !0;
            var b = Qk();
            return b.active && b.Tc ? !!b.Tc[String(a)] : !0
        };
    var el = !1;
    var fl = function() {
            this.m = {}
        },
        gl = function(a, b, c) {
            null != c && (a.m[b] = c)
        },
        hl = function(a) {
            return Object.keys(a.m).map(function(b) {
                return encodeURIComponent(b) + "=" + encodeURIComponent(a.m[b])
            }).join("&")
        },
        jl = function(a, b, c, d, e) {};
    var ll = /[A-Z]+/,
        ml = /\s/,
        nl = function(a) {
            if (k(a)) {
                a = Ca(a);
                var b = a.indexOf("-");
                if (!(0 > b)) {
                    var c = a.substring(0, b);
                    if (ll.test(c)) {
                        for (var d = a.substring(b + 1).split("/"), e = 0; e < d.length; e++)
                            if (!d[e] || ml.test(d[e]) && ("AW" !== c || 1 !== e)) return;
                        return {
                            id: a,
                            prefix: c,
                            containerId: c + "-" + d[0],
                            J: d
                        }
                    }
                }
            }
        },
        pl = function(a) {
            for (var b = {}, c = 0; c < a.length; ++c) {
                var d = nl(a[c]);
                d && (b[d.id] = d)
            }
            ol(b);
            var e = [];
            wa(b, function(f, g) {
                e.push(g)
            });
            return e
        };

    function ol(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                "AW" === d.prefix && d.J[1] && b.push(d.containerId)
            }
        for (var e = 0; e < b.length; ++e) delete a[b[e]]
    };
    var rl = function(a, b, c) {
            if (G[a.functionName]) return b.ef && J(b.ef), G[a.functionName];
            var d = ql();
            G[a.functionName] = d;
            if (a.Gd)
                for (var e = 0; e < a.Gd.length; e++) G[a.Gd[e]] = G[a.Gd[e]] || ql();
            a.Rd && void 0 === G[a.Rd] && (G[a.Rd] = c);
            fb(dk("https://", "http://", a.pf), b.ef, b.nj);
            return d
        },
        ql = function() {
            var a = function() {
                a.q = a.q || [];
                a.q.push(arguments)
            };
            return a
        },
        sl = {
            functionName: "_googWcmImpl",
            Rd: "_googWcmAk",
            pf: "www.gstatic.com/wcm/loader.js"
        },
        tl = {
            functionName: "_gaPhoneImpl",
            Rd: "ga_wpid",
            pf: "www.gstatic.com/gaphone/loader.js"
        },
        ul = {
            rh: "",
            mi: "5"
        },
        vl = {
            functionName: "_googCallTrackingImpl",
            Gd: [tl.functionName, sl.functionName],
            pf: "www.gstatic.com/call-tracking/call-tracking_" + (ul.rh || ul.mi) + ".js"
        },
        wl = {},
        xl = function(a, b, c, d) {
            S(22);
            if (c) {
                d = d || {};
                var e = rl(sl, d, a),
                    f = {
                        ak: a,
                        cl: b
                    };
                void 0 === d.Ta && (f.autoreplace = c);
                e(2, d.Ta, f, c, 0, Da(), d.options)
            }
        },
        yl = function(a, b, c, d) {
            S(21);
            if (b && c) {
                d = d || {};
                for (var e = {
                        countryNameCode: c,
                        destinationNumber: b,
                        retrievalTime: Da()
                    }, f = 0; f < a.length; f++) {
                    var g = a[f];
                    wl[g.id] ||
                        (g && "AW" === g.prefix && !e.adData && 2 <= g.J.length ? (e.adData = {
                            ak: g.J[0],
                            cl: g.J[1]
                        }, wl[g.id] = !0) : g && "UA" === g.prefix && !e.gaData && (e.gaData = {
                            gaWpid: g.containerId
                        }, wl[g.id] = !0))
                }(e.gaData || e.adData) && rl(vl, d)(d.Ta, e, d.options)
            }
        },
        zl = function() {
            var a = !1;
            return a
        },
        Al = function(a, b) {
            if (a)
                if (bk()) {} else {
                    if (k(a)) {
                        var c =
                            nl(a);
                        if (!c) return;
                        a = c
                    }
                    var d = void 0,
                        e = !1,
                        f = b.getWithConfig(R.Uh);
                    if (f && pa(f)) {
                        d = [];
                        for (var g = 0; g < f.length; g++) {
                            var l = nl(f[g]);
                            l && (d.push(l), (a.id === l.id || a.id === a.containerId && a.containerId === l.containerId) && (e = !0))
                        }
                    }
                    if (!d || e) {
                        var m = b.getWithConfig(R.Pf),
                            n;
                        if (m) {
                            pa(m) ? n = m : n = [m];
                            var p = b.getWithConfig(R.Nf),
                                q = b.getWithConfig(R.Of),
                                r = b.getWithConfig(R.Qf),
                                u = b.getWithConfig(R.Th),
                                t = p || q,
                                v = 1;
                            "UA" !== a.prefix || d || (v = 5);
                            for (var y = 0; y < n.length; y++)
                                if (y < v)
                                    if (d) yl(d, n[y], u, {
                                        Ta: t,
                                        options: r
                                    });
                                    else if ("AW" === a.prefix &&
                                a.J[1]) zl() ? yl([a], n[y], u || "US", {
                                Ta: t,
                                options: r
                            }) : xl(a.J[0], a.J[1], n[y], {
                                Ta: t,
                                options: r
                            });
                            else if ("UA" === a.prefix)
                                if (zl()) yl([a], n[y], u || "US", {
                                    Ta: t
                                });
                                else {
                                    var x = a.containerId,
                                        w = n[y],
                                        A = {
                                            Ta: t
                                        };
                                    S(23);
                                    if (w) {
                                        A = A || {};
                                        var z = rl(tl, A, x),
                                            D = {};
                                        void 0 !== A.Ta ? D.receiver = A.Ta : D.replace = w;
                                        D.ga_wpid = x;
                                        D.destination = w;
                                        z(2, Da(), D)
                                    }
                                }
                        }
                    }
                }
        };
    var Il = !1;

    function Jl() {
        if (na(Za.joinAdInterestGroup)) return !0;
        Il || (Dk(''), Il = !0);
        return na(Za.joinAdInterestGroup)
    }

    function Kl(a, b) {
        var c = void 0;
        try {
            c = H.querySelector('iframe[data-tagging-id="' + b + '"]')
        } catch (e) {}
        if (c) {
            var d = Number(c.dataset.loadTime);
            if (d && 6E4 > B() - d) {
                Pc("TAGGING", 9);
                return
            }
        } else try {
            if (50 <= H.querySelectorAll('iframe[allow="join-ad-interest-group"][data-tagging-id*="-"]').length) {
                Pc("TAGGING", 10);
                return
            }
        } catch (e) {}
        hb(a, void 0, {
            allow: "join-ad-interest-group"
        }, {
            taggingId: b,
            loadTime: B()
        }, c)
    };
    var tm = function(a, b, c) {
            this.s = a;
            this.eventName = b;
            this.m = c;
            this.o = {};
            this.metadata = {};
            this.I = !1
        },
        um = function(a, b, c) {
            var d = a.m.getWithConfig(b);
            void 0 !== d ? a.o[b] = d : void 0 !== c && (a.o[b] = c)
        },
        vm = function(a, b, c) {
            var d = Ae(a.s);
            return d && d.hasOwnProperty(b) ? d[b] : c
        };

    function wm(a) {
        return {
            getDestinationId: function() {
                return a.s
            },
            getEventName: function() {
                return a.eventName
            },
            setEventName: function(b) {
                return void(a.eventName = b)
            },
            getHitData: function(b) {
                return a.o[b]
            },
            setHitData: function(b, c) {
                return void(a.o[b] = c)
            },
            setHitDataIfNotDefined: function(b, c) {
                void 0 === a.o[b] && (a.o[b] = c)
            },
            copyToHitData: function(b, c) {
                um(a, b, c)
            },
            getMetadata: function(b) {
                return a.metadata[b]
            },
            setMetadata: function(b, c) {
                return void(a.metadata[b] = c)
            },
            abort: function() {
                return void(a.I = !0)
            },
            getProcessedEvent: function() {
                return a
            }
        }
    };
    var Um = function() {
            var a = !0;
            Yk(7) && Yk(9) && Yk(10) || (a = !1);
            return a
        },
        Vm = function() {
            var a = !0;
            Yk(3) && Yk(4) || (a = !1);
            return a
        };
    var Zm = function(a, b) {},
        $m = function(a, b) {
            var c = a[R.Ac],
                d = b + ".",
                e = a[R.M] || "",
                f = void 0 === c ? !!a.use_anchor : "fragment" ===
                c,
                g = !!a[R.Ob];
            e = String(e).replace(/\s+/g, "").split(",");
            var l = Gj();
            l(d + "require", "linker");
            l(d + "linker:autoLink", e, f, g)
        },
        dn = function(a, b, c) {
            if (id() && (!c.isGtmEvent || !an[a])) {
                var d = !vd(R.K),
                    e = function(f) {
                        var g, l, m = Gj(),
                            n = bn(b, "", c),
                            p, q = n.createOnlyFields._useUp;
                        if (c.isGtmEvent || cn(b, n.createOnlyFields)) {
                            c.isGtmEvent && (g = "gtm" + ke(), l = n.createOnlyFields, n.gtmTrackerName && (l.name = g));
                            m(function() {
                                var u = m.getByName(b);
                                u && (p = u.get("clientId"));
                                c.isGtmEvent || m.remove(b)
                            });
                            m("create", a, c.isGtmEvent ? l : n.createOnlyFields);
                            d && vd(R.K) && (d = !1, m(function() {
                                var u = Gj().getByName(c.isGtmEvent ? g : b);
                                !u || u.get("clientId") == p && q || (c.isGtmEvent ? (n.fieldsToSet["&gcu"] = "1", n.fieldsToSet["&gcut"] = R.ae[f]) : (n.fieldsToSend["&gcu"] = "1", n.fieldsToSend["&gcut"] = R.ae[f]), u.set(n.fieldsToSet), c.isGtmEvent ? u.send("pageview") : u.send("pageview", n.fieldsToSend))
                            }));
                            c.isGtmEvent && m(function() {
                                m.remove(g)
                            })
                        }
                    };
                xd(function() {
                    return e(R.K)
                }, R.K);
                xd(function() {
                    return e(R.D)
                }, R.D);
                c.isGtmEvent && (an[a] = !0)
            }
        },
        en = function(a, b) {
            ak() && b && (a[R.pb] = b)
        },
        on = function(a, b, c) {
            function d() {
                var I = c.getWithConfig(R.vc);
                l(function() {
                    if (!c.isGtmEvent && vb(I)) {
                        var O = t.fieldsToSend,
                            N = m().getByName(n),
                            M;
                        for (M in I)
                            if (I.hasOwnProperty(M) && /^(dimension|metric)\d+$/.test(M) && void 0 != I[M]) {
                                var L = N.get(Ym(I[M]));
                                fn(O, M, L)
                            }
                    }
                })
            }

            function e() {
                if (t.displayfeatures) {
                    var I = "_dc_gtm_" + f.replace(/[^A-Za-z0-9-]/g,
                        "");
                    p("require", "displayfeatures", void 0, {
                        cookieName: I
                    })
                }
            }
            var f = a,
                g = "https://www.google-analytics.com/analytics.js",
                l = c.isGtmEvent ? Ij(c.getWithConfig("gaFunctionName")) : Ij();
            if (na(l)) {
                var m = Gj,
                    n;
                c.isGtmEvent ? n = c.getWithConfig("name") || c.getWithConfig("gtmTrackerName") : n = "gtag_" + f.split("-").join("_");
                var p = function(I) {
                        var O = [].slice.call(arguments, 0);
                        O[0] = n ? n + "." + O[0] : "" + O[0];
                        l.apply(window, O)
                    },
                    q = function(I) {
                        var O = function(Q, da) {
                                for (var xa = 0; da && xa < da.length; xa++) p(Q, da[xa])
                            },
                            N = c.isGtmEvent,
                            M = N ? gn(t) :
                            hn(b, c);
                        if (M) {
                            var L = {};
                            en(L, I);
                            p("require", "ec", "ec.js", L);
                            N && M.Te && p("set", "&cu", M.Te);
                            var U = M.action;
                            if (N || "impressions" === U)
                                if (O("ec:addImpression", M.Ng), !N) return;
                            if ("promo_click" === U || "promo_view" === U || N && M.Sc) {
                                var V = M.Sc;
                                O("ec:addPromo", V);
                                if (V && 0 < V.length && "promo_click" === U) {
                                    N ? p("ec:setAction", U, M.ib) : p("ec:setAction", U);
                                    return
                                }
                                if (!N) return
                            }
                            "promo_view" !== U && "impressions" !== U && (O("ec:addProduct", M.Bb), p("ec:setAction", U, M.ib))
                        }
                    },
                    r = function(I) {
                        if (I) {
                            var O = {};
                            if (vb(I))
                                for (var N in jn) jn.hasOwnProperty(N) &&
                                    kn(jn[N], N, I[N], O);
                            en(O, x);
                            p("require", "linkid", O)
                        }
                    },
                    u = function() {
                        if (bk()) {} else {
                            var I = c.getWithConfig(R.Sh);
                            I && (p("require", I, {
                                dataLayer: Zd.W
                            }), p("require", "render"))
                        }
                    },
                    t = bn(n, b, c),
                    v = function(I, O, N) {
                        N && (O = "" + O);
                        t.fieldsToSend[I] = O
                    };
                !c.isGtmEvent && cn(n, t.createOnlyFields) && (l(function() {
                    m() && m().remove(n)
                }), ln[n] = !1);
                l("create", f, t.createOnlyFields);
                if (t.createOnlyFields[R.pb] && !c.isGtmEvent) {
                    var y = Yj(t.createOnlyFields[R.pb],
                        "/analytics.js");
                    y && (g = y)
                }
                var x = c.isGtmEvent ? t.fieldsToSet[R.pb] : t.createOnlyFields[R.pb];
                if (x) {
                    var w = c.isGtmEvent ? t.fieldsToSet[R.jd] : t.createOnlyFields[R.jd];
                    w && !ln[n] && (ln[n] = !0, l(Mj(n, w)))
                }
                c.isGtmEvent ? t.enableRecaptcha && p("require", "recaptcha", "recaptcha.js") : (d(), r(t.linkAttribution));
                var A = t[R.la];
                A && A[R.M] && $m(A, n);
                p("set", t.fieldsToSet);
                if (c.isGtmEvent) {
                    if (t.enableLinkId) {
                        var z = {};
                        en(z, x);
                        p("require", "linkid", "linkid.js", z)
                    }
                    id() && dn(f, n, c)
                }
                if (b === R.jc)
                    if (c.isGtmEvent) {
                        e();
                        if (t.remarketingLists) {
                            var D =
                                "_dc_gtm_" + f.replace(/[^A-Za-z0-9-]/g, "");
                            p("require", "adfeatures", {
                                cookieName: D
                            })
                        }
                        q(x);
                        p("send", "pageview");
                        t.createOnlyFields._useUp && Jj(n + ".")
                    } else u(), p("send", "pageview", t.fieldsToSend);
                else b === R.Ca ? (u(), Al(f, c), c.getWithConfig(R.hb) && (fh(["aw", "dc"]), Jj(n + ".")), 0 != t.sendPageView && p("send", "pageview", t.fieldsToSend), dn(f, n, c), !c.isGtmEvent && 0 < c.getEventModelKeys().length && (S(68), 1 < T.configCount && S(69))) : b === R.Ia ? Zm(n, c) : "screen_view" === b ? p("send", "screenview", t.fieldsToSend) : "timing_complete" ===
                    b ? (t.fieldsToSend.hitType = "timing", v("timingCategory", t.eventCategory, !0), c.isGtmEvent ? v("timingVar", t.timingVar, !0) : v("timingVar", t.name, !0), v("timingValue", za(t.value)), void 0 !== t.eventLabel && v("timingLabel", t.eventLabel, !0), p("send", t.fieldsToSend)) : "exception" === b ? p("send", "exception", t.fieldsToSend) : "" === b && c.isGtmEvent || ("track_social" === b && c.isGtmEvent ? (t.fieldsToSend.hitType = "social", v("socialNetwork", t.socialNetwork, !0), v("socialAction", t.socialAction, !0), v("socialTarget", t.socialTarget, !0)) : ((c.isGtmEvent || mn[b]) && q(x), c.isGtmEvent && e(), t.fieldsToSend.hitType = "event", v("eventCategory", t.eventCategory, !0), v("eventAction", t.eventAction || b, !0), void 0 !== t.eventLabel && v("eventLabel", t.eventLabel, !0), void 0 !== t.value && v("eventValue", za(t.value))), p("send", t.fieldsToSend));
                var C = !1;
                var E = nn;
                C && (E = c.getContainerTypeLoaded("UA"));
                if (!E &&
                    !c.isGtmEvent) {
                    nn = !0;
                    C && c.setContainerTypeLoaded("UA", !0);
                    lj();
                    var F = function() {
                            C && c.setContainerTypeLoaded("UA", !1);
                            c.onFailure()
                        },
                        K = function() {
                            m().loaded || F()
                        };
                    bk() ? J(K) : fb(g, K, F)
                }
            } else J(c.onFailure)
        },
        pn = function(a, b, c, d) {
            yd(function() {
                on(a, b, d)
            }, [R.K, R.D])
        },
        rn = function(a, b) {
            function c(f) {
                function g(p, q) {
                    for (var r = 0; r < q.length; r++) {
                        var u = q[r];
                        if (f[u]) {
                            m[p] = f[u];
                            break
                        }
                    }
                }

                function l() {
                    if (f.category) m.category = f.category;
                    else {
                        for (var p = "", q = 0; q < qn.length; q++) void 0 !== f[qn[q]] && (p && (p += "/"), p += f[qn[q]]);
                        p && (m.category = p)
                    }
                }
                var m = P(f),
                    n = !1;
                if (n || b) g("id", ["id", "item_id", "promotion_id"]), g("name", ["name", "item_name", "promotion_name"]), g("brand", ["brand", "item_brand"]), g("variant", ["variant", "item_variant"]), g("list", ["list_name", "item_list_name"]), g("position", ["list_position", "creative_slot", "index"]), l();
                g("listPosition", ["list_position"]);
                g("creative", ["creative_name"]);
                g("list", ["list_name"]);
                g("position", ["list_position", "creative_slot"]);
                return m
            }
            b = void 0 === b ? !1 : b;
            for (var d = [], e = 0; a && e < a.length; e++) a[e] && vb(a[e]) && d.push(c(a[e]));
            return d.length ? d : void 0
        },
        sn = function(a) {
            return vd(a)
        },
        tn = !1;
    var nn, ln = {},
        an = {},
        un = {},
        Wm = Object.freeze((un.client_storage = "storage", un.sample_rate = 1, un.site_speed_sample_rate = 1, un.store_gac = 1, un.use_amp_client_id = 1, un[R.ja] = 1, un[R.va] =
            "storeGac", un[R.ka] = 1, un[R.wa] = 1, un[R.Ka] = 1, un[R.Kb] = 1, un[R.Za] = 1, un[R.Lb] = 1, un)),
        vn = {},
        wn = Object.freeze((vn._cs = 1, vn._useUp = 1, vn.allowAnchor = 1, vn.allowLinker = 1, vn.alwaysSendReferrer = 1, vn.clientId = 1, vn.cookieDomain = 1, vn.cookieExpires = 1, vn.cookieFlags = 1, vn.cookieName = 1, vn.cookiePath = 1, vn.cookieUpdate = 1, vn.legacyCookieDomain = 1, vn.legacyHistoryImport = 1, vn.name = 1, vn.sampleRate = 1, vn.siteSpeedSampleRate = 1, vn.storage = 1, vn.storeGac = 1, vn.useAmpClientId = 1, vn._cd2l = 1, vn)),
        xn = Object.freeze({
            anonymize_ip: 1
        }),
        yn = {},
        Xm = Object.freeze((yn.campaign = {
            content: "campaignContent",
            id: "campaignId",
            medium: "campaignMedium",
            name: "campaignName",
            source: "campaignSource",
            term: "campaignKeyword"
        }, yn.app_id = 1, yn.app_installer_id = 1, yn.app_name = 1, yn.app_version = 1, yn.description = "exDescription", yn.fatal = "exFatal", yn.language = 1, yn.page_hostname = "hostname", yn.transport_type = "transport", yn[R.da] = "currencyCode", yn[R.Lf] = 1, yn[R.Sa] = "location", yn[R.ze] = "page", yn[R.La] = "referrer", yn[R.Bc] = "title", yn[R.Tf] = 1, yn[R.Ea] = 1, yn)),
        zn = {},
        An =
        Object.freeze((zn.content_id = 1, zn.event_action = 1, zn.event_category = 1, zn.event_label = 1, zn.link_attribution = 1, zn.name = 1, zn[R.la] = 1, zn[R.Kf] = 1, zn[R.xa] = 1, zn[R.ia] = 1, zn)),
        Bn = Object.freeze({
            displayfeatures: 1,
            enableLinkId: 1,
            enableRecaptcha: 1,
            eventAction: 1,
            eventCategory: 1,
            eventLabel: 1,
            gaFunctionName: 1,
            gtmEcommerceData: 1,
            gtmTrackerName: 1,
            linker: 1,
            remarketingLists: 1,
            socialAction: 1,
            socialNetwork: 1,
            socialTarget: 1,
            timingVar: 1,
            value: 1
        }),
        qn = Object.freeze(["item_category", "item_category2", "item_category3", "item_category4",
            "item_category5"
        ]),
        Cn = {},
        jn = Object.freeze((Cn.levels = 1, Cn[R.wa] = "duration", Cn[R.Kb] = 1, Cn)),
        Dn = {},
        En = Object.freeze((Dn.anonymize_ip = 1, Dn.fatal = 1, Dn.send_page_view = 1, Dn.store_gac = 1, Dn.use_amp_client_id = 1, Dn[R.va] = 1, Dn[R.Lf] = 1, Dn)),
        kn = function(a, b, c, d) {
            if (void 0 !== c)
                if (En[b] && (c = Aa(c)), "anonymize_ip" !== b || c || (c = void 0), 1 === a) d[Ym(b)] = c;
                else if (k(a)) d[a] = c;
            else
                for (var e in a) a.hasOwnProperty(e) && void 0 !== c[e] && (d[a[e]] = c[e])
        },
        Ym = function(a) {
            return a && k(a) ? a.replace(/(_[a-z])/g, function(b) {
                    return b[1].toUpperCase()
                }) :
                a
        },
        Fn = {},
        mn = Object.freeze((Fn.checkout_progress = 1, Fn.select_content = 1, Fn.set_checkout_option = 1, Fn[R.Gb] = 1, Fn[R.Hb] = 1, Fn[R.lb] = 1, Fn[R.nb] = 1, Fn[R.Ib] = 1, Fn[R.qa] = 1, Fn[R.Jb] = 1, Fn[R.ra] = 1, Fn)),
        Gn = {},
        Hn = Object.freeze((Gn.checkout_progress = 1, Gn.set_checkout_option = 1, Gn[R.Af] = 1, Gn[R.Gb] = 1, Gn[R.Hb] = 1, Gn[R.lb] = 1, Gn[R.qa] = 1, Gn[R.Jb] = 1, Gn[R.Bf] = 1, Gn)),
        In = {},
        Jn = Object.freeze((In.generate_lead = 1, In.login = 1, In.search = 1, In.select_content = 1, In.share = 1, In.sign_up = 1, In.view_search_results = 1, In[R.nb] = 1, In[R.Ib] = 1, In[R.ra] =
            1, In)),
        Kn = function(a) {
            var b = "general";
            Hn[a] ? b = "ecommerce" : Jn[a] ? b = "engagement" : "exception" === a && (b = "error");
            return b
        },
        Ln = {},
        Mn = Object.freeze((Ln.view_search_results = 1, Ln[R.nb] = 1, Ln[R.Ib] = 1, Ln[R.ra] = 1, Ln)),
        fn = function(a, b, c) {
            a.hasOwnProperty(b) || (a[b] = c)
        },
        Nn = function(a) {
            if (pa(a)) {
                for (var b = [], c = 0; c < a.length; c++) {
                    var d = a[c];
                    if (void 0 != d) {
                        var e = d.id,
                            f = d.variant;
                        void 0 != e && void 0 != f && b.push(String(e) + "." + String(f))
                    }
                }
                return 0 < b.length ? b.join("!") : void 0
            }
        },
        bn = function(a, b, c) {
            var d = function(K) {
                    return c.getWithConfig(K)
                },
                e = {},
                f = {},
                g = {},
                l = {},
                m = Nn(d(R.Rh));
            !c.isGtmEvent && m && fn(f, "exp", m);
            g["&gtm"] = yk(!0);
            id() && (l._cs = sn);
            var n = d(R.vc);
            if (!c.isGtmEvent && vb(n))
                for (var p in n)
                    if (n.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) && void 0 != n[p]) {
                        var q = d(String(n[p]));
                        void 0 !== q && fn(f, p, q)
                    }
            for (var r = c.getTopLevelKeys(), u = 0; u < r.length; ++u) {
                var t = r[u];
                if (c.isGtmEvent) {
                    var v = d(t);
                    Bn.hasOwnProperty(t) ? e[t] = v : wn.hasOwnProperty(t) ? l[t] = v : g[t] = v
                } else {
                    var y = void 0;
                    y = t !== R.T ? d(t) : c.getMergedValues(t);
                    if (An.hasOwnProperty(t)) kn(An[t],
                        t, y, e);
                    else if (xn.hasOwnProperty(t)) kn(xn[t], t, y, g);
                    else if (Xm.hasOwnProperty(t)) kn(Xm[t], t, y, f);
                    else if (Wm.hasOwnProperty(t)) kn(Wm[t], t, y, l);
                    else if (/^(dimension|metric|content_group)\d+$/.test(t)) kn(1, t, y, f);
                    else if (t === R.T) {
                        if (!tn) {
                            var x = Ma(y);
                            x && (f["&did"] = x)
                        }
                        var w = void 0,
                            A = void 0;
                        b === R.Ca ? w = Ma(c.getMergedValues(t), ".") : (w = Ma(c.getMergedValues(t, 1), "."), A = Ma(c.getMergedValues(t, 2), "."));
                        w && (f["&gdid"] = w);
                        A && (f["&edid"] = A)
                    } else t === R.Da && 0 > r.indexOf(R.Kb) && (l.cookieName = y + "_ga")
                }
            }!1 !== d(R.Hh) &&
                !1 !== d(R.kc) && Um() || (g.allowAdFeatures = !1);
            !1 !== d(R.X) && Vm() || (g.allowAdPersonalizationSignals = !1);
            !c.isGtmEvent && d(R.hb) && (l._useUp = !0);
            if (c.isGtmEvent) {
                l.name = l.name || e.gtmTrackerName;
                var z = g.hitCallback;
                g.hitCallback = function() {
                    na(z) && z();
                    c.onSuccess()
                }
            } else {
                fn(l, "cookieDomain", "auto");
                fn(g, "forceSSL", !0);
                fn(e, "eventCategory", Kn(b));
                Mn[b] && fn(f, "nonInteraction", !0);
                "login" === b || "sign_up" === b || "share" === b ? fn(e, "eventLabel", d(R.Kf)) : "search" === b || "view_search_results" === b ? fn(e, "eventLabel", d(R.Yh)) :
                    "select_content" === b && fn(e, "eventLabel", d(R.Lh));
                var D = e[R.la] || {},
                    C = D[R.Nb];
                C || 0 != C && D[R.M] ? l.allowLinker = !0 : !1 === C && fn(l, "useAmpClientId", !1);
                f.hitCallback = c.onSuccess;
                l.name = a
            }
            id() && (g["&gcs"] = wd(), vd(R.K) || (l.storage = "none"), vd(R.D) || (g.allowAdFeatures = !1, l.storeGac = !1));
            var E = d(R.U) || d(R.pb),
                F = d(R.jd);
            E && (c.isGtmEvent || (l[R.pb] = E), l._cd2l = !0);
            F && !c.isGtmEvent && (l[R.jd] = F);
            e.fieldsToSend = f;
            e.fieldsToSet = g;
            e.createOnlyFields = l;
            return e
        },
        gn = function(a) {
            var b = a.gtmEcommerceData;
            if (!b) return null;
            var c = {};
            b.currencyCode && (c.Te = b.currencyCode);
            if (b.impressions) {
                c.action = "impressions";
                var d = b.impressions;
                c.Ng = "impressions" === b.translateIfKeyEquals ? rn(d, !0) : d
            }
            if (b.promoView) {
                c.action = "promo_view";
                var e = b.promoView.promotions;
                c.Sc = "promoView" === b.translateIfKeyEquals ? rn(e, !0) : e
            }
            if (b.promoClick) {
                c.action = "promo_click";
                var f = b.promoClick.promotions;
                c.Sc = "promoClick" === b.translateIfKeyEquals ? rn(f, !0) : f;
                c.ib = b.promoClick.actionField;
                return c
            }
            for (var g in b)
                if (b.hasOwnProperty(g) && "translateIfKeyEquals" !==
                    g && "impressions" !== g && "promoView" !== g && "promoClick" !== g && "currencyCode" !== g) {
                    c.action = g;
                    var l = b[g].products;
                    c.Bb = "products" === b.translateIfKeyEquals ? rn(l, !0) : l;
                    c.ib = b[g].actionField;
                    break
                }
            return Object.keys(c).length ? c : null
        },
        hn = function(a, b) {
            function c(u) {
                return {
                    id: d(R.fb),
                    affiliation: d(R.Oh),
                    revenue: d(R.ia),
                    tax: d(R.Ff),
                    shipping: d(R.se),
                    coupon: d(R.Ph),
                    list: d(R.qe) || u
                }
            }
            for (var d = function(u) {
                    return b.getWithConfig(u)
                }, e = d(R.Z), f, g = 0; e && g < e.length && !(f = e[g][R.qe]); g++);
            var l = d(R.vc);
            if (vb(l))
                for (var m =
                        0; e && m < e.length; ++m) {
                    var n = e[m],
                        p;
                    for (p in l) l.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) && void 0 != l[p] && fn(n, p, n[l[p]])
                }
            var q = null,
                r = d(R.Qh);
            a === R.qa || a === R.Jb ? q = {
                    action: a,
                    ib: c(),
                    Bb: rn(e)
                } : a === R.Gb ? q = {
                    action: "add",
                    Bb: rn(e)
                } : a === R.Hb ? q = {
                    action: "remove",
                    Bb: rn(e)
                } : a === R.ra ? q = {
                    action: "detail",
                    ib: c(f),
                    Bb: rn(e)
                } : a === R.nb ? q = {
                    action: "impressions",
                    Ng: rn(e)
                } : "view_promotion" === a ? q = {
                    action: "promo_view",
                    Sc: rn(r)
                } : "select_content" === a && r && 0 < r.length ? q = {
                    action: "promo_click",
                    Sc: rn(r)
                } : "select_content" ===
                a ? q = {
                    action: "click",
                    ib: {
                        list: d(R.qe) || f
                    },
                    Bb: rn(e)
                } : a === R.lb || "checkout_progress" === a ? q = {
                    action: "checkout",
                    Bb: rn(e),
                    ib: {
                        step: a === R.lb ? 1 : d(R.Ef),
                        option: d(R.Df)
                    }
                } : "set_checkout_option" === a && (q = {
                    action: "checkout_option",
                    ib: {
                        step: d(R.Ef),
                        option: d(R.Df)
                    }
                });
            q && (q.Te = d(R.da));
            return q
        },
        On = {},
        cn = function(a, b) {
            var c = On[a];
            On[a] = P(b);
            if (!c) return !1;
            for (var d in b)
                if (b.hasOwnProperty(d) && b[d] !== c[d]) return !0;
            for (var e in c)
                if (c.hasOwnProperty(e) && c[e] !== b[e]) return !0;
            return !1
        };
    var Pn = null,
        Qn = !1;

    function Rn(a) {
        return Qn && !a ? Pn = Pn || new Sn : T.gcq = T.gcq || new Sn
    }
    var Tn = function(a, b, c) {
            Rn().register(a, b, c)
        },
        Un = function(a, b, c, d) {
            Rn().push("event", [b, a], c, d)
        },
        Vn = function(a, b) {
            Rn().push("config", [a], b)
        },
        Wn = function(a, b, c, d) {
            Rn().push("get", [a, b], c, d)
        },
        Xn = function() {
            var a = R.U;
            return Rn().getGlobalConfigValue && Rn().getGlobalConfigValue(a)
        },
        Yn = {},
        Zn = function() {
            this.status = 1;
            this.containerConfig = {};
            this.targetConfig = {};
            this.remoteConfig = {};
            this.o = {};
            this.s = null;
            this.claimed = this.m = !1
        },
        $n = function(a, b, c, d, e) {
            this.type = a;
            this.s = b;
            this.O = c || "";
            this.m = d;
            this.o = e
        },
        Sn =
        function() {
            this.o = {};
            this.s = {};
            this.m = [];
            this.C = {
                AW: !1,
                UA: !1
            }
        },
        ao = function(a, b) {
            var c = nl(b);
            return a.o[c.containerId] = a.o[c.containerId] || new Zn
        },
        bo = function(a, b, c, d) {
            if (b) {
                var e = nl(b);
                if (e && 1 === ao(a, b).status) {
                    ao(a, b).status = 2;
                    var f = {};
                    zi && (f.timeoutId = G.setTimeout(function() {
                        S(38);
                        bi()
                    }, 3E3));
                    a.push("require", [f], e.containerId);
                    Yn[e.containerId] = B();
                    if (bk()) {} else 2 === d ? hk(e.containerId, c) : gk(e.containerId, c, !0)
                }
            }
        },
        co = function(a, b, c, d) {
            if (d.O) {
                var e = ao(a, d.O),
                    f = e.s;
                if (f) {
                    var g = P(c),
                        l = P(e.targetConfig[d.O]),
                        m = P(e.containerConfig),
                        n = P(e.remoteConfig),
                        p = P(a.s),
                        q = {};
                    try {
                        q = P(ne)
                    } catch (y) {
                        S(72)
                    }
                    var r = qe("gtm.uniqueEventId"),
                        u = nl(d.O).prefix,
                        t = Ga(function() {
                            var y = g[R.Mb];
                            y && J(y)
                        }),
                        v = rk(qk(sk(pk(nk(mk(ok(lk(kk(jk(g), l), m), n), p), q), function() {
                            Mi(r, u, "2");
                            t()
                        }), function() {
                            Mi(r, u, "3");
                            t()
                        }), function(y, x) {
                            a.C[y] = x
                        }), function(y) {
                            return a.C[y]
                        });
                    try {
                        Mi(r, u, "1"), Vi(d.type, d.O, v);
                        f(d.O, b, d.s, v)
                    } catch (y) {
                        Mi(r, u, "4");
                    }
                }
            }
        };
    h = Sn.prototype;
    h.register = function(a, b, c) {
        var d = ao(this, a);
        if (3 !== d.status) {
            d.s = b;
            d.status = 3;
            c && (P(d.remoteConfig, c), d.remoteConfig = c);
            var e = nl(a),
                f = Yn[e.containerId];
            if (void 0 !== f) {
                var g = T[e.containerId].bootstrap,
                    l = e.prefix.toUpperCase();
                T[e.containerId]._spx && (l = l.toLowerCase());
                var m = qe("gtm.uniqueEventId"),
                    n = l,
                    p = B() - g;
                if (zi && !gi[m]) {
                    m !== ci && (Yh(), ci = m);
                    var q = n + "." + Math.floor(g - f) + "." + Math.floor(p);
                    ni = ni ? ni + "," + q : "&cl=" + q
                }
                delete Yn[e.containerId]
            }
            this.flush()
        }
    };
    h.notifyContainerLoaded = function(a, b) {
        var c = this,
            d = function(f) {
                if (nl(f)) {
                    var g = ao(c, f);
                    g.status = 3;
                    g.claimed = !0
                }
            };
        d(a);
        for (var e = 0; e < b.length; e++) d(b[e]);
        this.flush()
    };
    h.push = function(a, b, c, d) {
        if (void 0 !== c) {
            if (!nl(c)) return;
            bo(this, c, b[0][R.U] || this.s[R.U], "event" === a ? 2 : 1);
            ao(this, c).m && (d = !1)
        }
        this.m.push(new $n(a, Math.floor(B() / 1E3), c, b, d));
        d || this.flush()
    };
    h.insert = function(a, b, c) {
        var d = Math.floor(B() / 1E3);
        0 < this.m.length ? this.m.splice(1, 0, new $n(a, d, c, b, !1)) : this.m.push(new $n(a, d, c, b, !1))
    };
    h.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.m.length;) {
            var f = this.m[0];
            if (f.o) !f.O || ao(this, f.O).m ? (f.o = !1, this.m.push(f)) : c.push(f), this.m.shift();
            else {
                var g = void 0;
                switch (f.type) {
                    case "require":
                        g = ao(this, f.O);
                        if (3 !== g.status && !a) {
                            this.m.push.apply(this.m, c);
                            return
                        }
                        zi && G.clearTimeout(f.m[0].timeoutId);
                        break;
                    case "set":
                        wa(f.m[0], function(r, u) {
                            P(Ka(r, u), b.s)
                        });
                        break;
                    case "config":
                        g = ao(this, f.O);
                        if (g.claimed) break;
                        e.Pa = {};
                        wa(f.m[0], function(r) {
                            return function(u, t) {
                                P(Ka(u, t), r.Pa)
                            }
                        }(e));
                        var l = !!e.Pa[R.qd];
                        delete e.Pa[R.qd];
                        var m = nl(f.O),
                            n = m.containerId === m.id;
                        l || (n ? g.containerConfig = {} : g.targetConfig[f.O] = {});
                        g.m && l || co(this, R.Ca, e.Pa, f);
                        g.m = !0;
                        delete e.Pa[R.sb];
                        n ? P(e.Pa, g.containerConfig) : (P(e.Pa, g.targetConfig[f.O]), S(70));
                        d = !0;
                        break;
                    case "event":
                        g = ao(this, f.O);
                        if (g.claimed) break;
                        e.Zc = {};
                        wa(f.m[0], function(r) {
                            return function(u, t) {
                                P(Ka(u, t), r.Zc)
                            }
                        }(e));
                        co(this, f.m[1], e.Zc, f);
                        break;
                    case "get":
                        if (g = ao(this, f.O), !g.claimed) {
                            var p = {},
                                q = (p[R.Ra] = f.m[0], p[R.ab] = f.m[1], p);
                            co(this, R.Ia, q, f)
                        }
                }
                this.m.shift();
                eo(this, f)
            }
            e = {
                Pa: e.Pa,
                Zc: e.Zc
            }
        }
        this.m.push.apply(this.m, c);
        d && this.flush()
    };
    var eo = function(a, b) {
        if ("require" !== b.type)
            if (b.O)
                for (var c = a.getCommandListeners(b.O)[b.type] || [], d = 0; d < c.length; d++) c[d]();
            else
                for (var e in a.o)
                    if (a.o.hasOwnProperty(e)) {
                        var f = a.o[e];
                        if (f && f.o)
                            for (var g = f.o[b.type] || [], l = 0; l < g.length; l++) g[l]()
                    }
    };
    Sn.prototype.getRemoteConfig = function(a) {
        return ao(this, a).remoteConfig
    };
    Sn.prototype.getCommandListeners = function(a) {
        return ao(this, a).o
    };
    Sn.prototype.getGlobalConfigValue = function(a) {
        return this.s[a]
    };
    var fo = [R.ic, R.Qb, R.yd],
        ho = function(a, b) {
            return 1 === arguments.length ? go("config", a) : go("config", a, b)
        },
        io = function(a, b, c) {
            c = c || {};
            c[R.qb] = a;
            if ("G" === a.split("-")[0])
                for (var d in c) "_" === d[0] && -1 === fo.indexOf(d) && delete c[d];
            return go("event", b, c)
        };

    function go(a) {
        return arguments
    }
    var ko = function(a) {
        if (jo(a)) return a;
        this.m = a
    };
    ko.prototype.getUntrustedMessageValue = function() {
        return this.m
    };
    var jo = function(a) {
            return !a || "object" !== tb(a) || vb(a) ? !1 : "getUntrustedMessageValue" in a
        },
        lo = function(a) {
            if (jo(a)) return a.getUntrustedMessageValue()
        };
    ko.prototype.getUntrustedMessageValue = ko.prototype.getUntrustedMessageValue;
    var mo = function() {
        this.m = [];
        this.o = []
    };
    mo.prototype.push = function(a, b, c) {
        var d = this.m.length + 1;
        jo(a) && (a = lo(a) || a);
        a["gtm.uniqueEventId"] = b;
        a["gtm.priorityId"] = d;
        a = new ko(a);
        var e = {
            debugContext: c,
            message: a,
            notBeforeEventId: b,
            priorityId: d
        };
        this.m.push(e);
        for (var f = 0; f < this.o.length; f++) try {
            this.o[f](e)
        } catch (g) {}
    };
    mo.prototype.listen = function(a) {
        this.o.push(a)
    };
    mo.prototype.get = function() {
        for (var a = {}, b = 0; b < this.m.length; b++) {
            var c = this.m[b],
                d = a[c.notBeforeEventId];
            d || (d = [], a[c.notBeforeEventId] = d);
            d.push(c)
        }
        return a
    };
    var oo = function(a, b, c) {
            no().push(a, b, c)
        },
        qo = function() {
            var a = po;
            no().listen(a)
        },
        ro = function(a, b) {
            return a.notBeforeEventId - b.notBeforeEventId || a.priorityId - b.priorityId
        };

    function no() {
        var a = T.mb;
        a || (a = new mo, T.mb = a);
        return a
    }
    var so = !1;
    var to = !1;
    var uo = function(a, b) {
        T.addDestinationToContainer ? T.addDestinationToContainer(a, b) : (T.pendingDestinationIds = T.pendingDestinationIds || [], T.pendingDestinationIds.push([a, b]))
    };
    var No = function(a) {
            var b = T.zones;
            return b ? b.getIsAllowedFn(Kh(), a) : function() {
                return !0
            }
        },
        Oo = function(a) {
            var b = T.zones;
            return b ? b.isActive(Kh(), a) : !0
        };
    var Ro = function(a, b) {
        for (var c = [], d = 0; d < Yb.length; d++)
            if (a[d]) {
                var e = Yb[d];
                var f = jj(b.ub);
                try {
                    var g = Rj(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var l = c,
                            m = l.push,
                            n = d,
                            p = e["function"];
                        if (!p) throw "Error: No function name given for function call.";
                        var q = $b[p];
                        m.call(l, {
                            gh: n,
                            Xg: q ? q.priorityOverride || 0 : 0,
                            execute: g
                        })
                    } else Po(d, b), f()
                } catch (u) {
                    f()
                }
            }
        c.sort(Qo);
        for (var r = 0; r < c.length; r++) c[r].execute();
        return 0 <
            c.length
    };

    function Qo(a, b) {
        var c, d = b.Xg,
            e = a.Xg;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (0 !== c) f = c;
        else {
            var g = a.gh,
                l = b.gh;
            f = g > l ? 1 : g < l ? -1 : 0
        }
        return f
    }

    function Po(a, b) {
        if (!zi) return;
        var c = function(d) {
            var e = b.$e(Yb[d]) ? "3" : "4",
                f = gc(Yb[d][xb.fg], b, []);
            f && f.length && c(f[0].index);
            Fi(b.id, Yb[d], e);
            var g = gc(Yb[d][xb.ig], b, []);
            g && g.length && c(g[0].index)
        };
        c(a);
    }
    var Uo = !1,
        So;
    var Zo = function(a) {
        var b = B(),
            c = a["gtm.uniqueEventId"],
            d = a["gtm.priorityId"],
            e = a.event;
        if ("gtm.js" === e) {
            if (Uo) return !1;
            Uo = !0;
        }
        var l, m = !1;
        if (Oo(c)) l = No(c);
        else {
            if ("gtm.js" !== e && "gtm.init" !== e && "gtm.init_consent" !== e) return !1;
            m = !0;
            l = No(Number.MAX_SAFE_INTEGER)
        }
        Ei(c, e);
        var n = a.eventCallback,
            p = a.eventTimeout,
            q = n;
        var r = {
                id: c,
                priorityId: d,
                name: e,
                $e: Hh(l),
                Nj: [],
                Qg: function() {
                    S(6)
                },
                xg: Vo(),
                yg: Wo(c),
                ub: new ej(q, p)
            },
            u = lc(r);
        m && (u = Xo(u));
        var t = Ro(u, r),
            v = !1;
        kj(r.ub);
        "gtm.js" !== e && "gtm.sync" !== e || Lj(Ih.H);
        return Yo(u, t) || v
    };

    function Wo(a) {
        return function(b) {
            zi && (wb(b) || Ni(a, "input", b))
        }
    }

    function Vo() {
        var a = {};
        a.event = xe("event", 1);
        a.ecommerce = xe("ecommerce", 1);
        a.gtm = xe("gtm");
        a.eventModel = xe("eventModel");
        return a
    }

    function Xo(a) {
        for (var b = [], c = 0; c < a.length; c++) a[c] && (ae[String(Yb[c][xb.tb])] && (b[c] = !0), void 0 !== Yb[c][xb.li] && (b[c] = !0));
        return b
    }

    function Yo(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && Yb[c] && !be[String(Yb[c][xb.tb])]) return !0;
        return !1
    }
    var $o = !1;
    var ap = "HA GF G UA AW DC".split(" "),
        bp = !1,
        cp = !1,
        dp = 0;

    function ep(a) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: ke()
        });
        return a["gtm.uniqueEventId"]
    }

    function fp(a) {
        delete a[R.yd];
        delete a[R.ic];
    }

    function gp() {
        return bp
    }
    var Bp = {
            config: function(a) {
                ep(a);
            },
            consent: function(a) {
                if (3 === a.length) {
                    S(39);
                    var b = {
                            eventId: ep(a),
                            priorityId: a["gtm.priorityId"]
                        },
                        c = a[1];
                    "default" === c ? sd(a[2]) : "update" === c && ud(a[2], b)
                }
            },
            event: function(a, b, c) {
                c = void 0 === c ? !1 : c;
                var d = a[1];
                if (!(2 > a.length) && k(d)) {
                    var e;
                    if (2 < a.length) {
                        if (!vb(a[2]) && void 0 != a[2] || 3 < a.length) return;
                        e = a[2]
                    }
                    var f = e,
                        g = {},
                        l = (g.event = d, g);
                    f && (l.eventModel = P(f), f[R.Mb] && (l.eventCallback = f[R.Mb]), f[R.hd] && (l.eventTimeout = f[R.hd]));
                    var m = !1,
                        n = !1;
                    if (e) {
                        e[R.yd] && 0 === Ih.H.indexOf("GTM") && (m = !0);
                        e[R.ic] && (n = !0);
                        fp(l.eventModel)
                    }
                    var p = ep(a),
                        q = a["gtm.priorityId"];
                    l["gtm.uniqueEventId"] = p;
                    q && (l["gtm.priorityId"] = q);
                    return m ? void 0 : l
                }
            },
            get: function(a) {},
            js: function(a) {
                if (2 == a.length && a[1].getTime) {
                    cp = !0;
                    gp();
                    var b = {};
                    return b.event = "gtm.js", b["gtm.start"] = a[1].getTime(), b["gtm.uniqueEventId"] = ep(a), b
                }
            },
            policy: function() {},
            set: function(a) {
                var b;
                2 == a.length && vb(a[1]) ? b = P(a[1]) : 3 == a.length && k(a[1]) && (b = {}, vb(a[2]) || pa(a[2]) ? b[a[1]] = P(a[2]) : b[a[1]] = a[2]);
                if (b) {
                    var c = ep(a),
                        d = a["gtm.priorityId"];
                    b._clear = !0;
                    return b
                }
            }
        },
        Cp = {
            policy: !0
        };
    var Dp = function(a) {
            var b = G[Zd.W].hide;
            if (b && void 0 !== b[a] && b.end) {
                b[a] = !1;
                var c = !0,
                    d;
                for (d in b)
                    if (b.hasOwnProperty(d) && !0 === b[d]) {
                        c = !1;
                        break
                    }
                c && (b.end(), b.end = null)
            }
        },
        Ep = function(a) {
            var b = G[Zd.W],
                c = b && b.hide;
            c && c.end && (c[a] = !0)
        };
    var Fp = !1,
        Gp = [];

    function Hp() {
        if (!Fp) {
            Fp = !0;
            for (var a = 0; a < Gp.length; a++) J(Gp[a])
        }
    }
    var Ip = function(a) {
        Fp ? J(a) : Gp.push(a)
    };
    var Yp = 0,
        Zp = {},
        $p = [],
        aq = [],
        bq = !1,
        cq = !1,
        dq = function(a) {
            return G[Zd.W].push(a)
        },
        eq = function(a, b) {
            var c = T[Zd.W],
                d = c ? c.subscribers : 1,
                e = 0,
                f = !1,
                g = void 0;
            b && (g = G.setTimeout(function() {
                f || (f = !0, a());
                g = void 0
            }, b));
            return function() {
                ++e === d && (g && (G.clearTimeout(g), g = void 0), f || (a(), f = !0))
            }
        };

    function fq(a) {
        var b = a._clear;
        wa(a, function(d, e) {
            "_clear" !== d && (b && te(d), te(d, e))
        });
        ge || (ge = a["gtm.start"]);
        var c = a["gtm.uniqueEventId"];
        if (!a.event) return !1;
        c || (c = ke(), a["gtm.uniqueEventId"] = c, te("gtm.uniqueEventId", c));
        return Zo(a)
    }

    function gq(a) {
        if (null == a || "object" !== typeof a) return !1;
        if (a.event) return !0;
        if (ya(a)) {
            var b = a[0];
            if ("config" === b || "event" === b || "js" === b) return !0
        }
        return !1
    }

    function hq() {
        for (var a = !1; !cq && (0 < $p.length || 0 < aq.length);) {
            if (!bq && gq($p[0])) {
                var b = {},
                    c = (b.event = "gtm.init_consent", b),
                    d = {},
                    e = (d.event = "gtm.init", d),
                    f = $p[0]["gtm.uniqueEventId"];
                f && (c["gtm.uniqueEventId"] = f - 2, e["gtm.uniqueEventId"] = f - 1);
                $p.unshift(c, e);
                bq = !0;
            }
            cq = !0;
            delete ne.eventModel;
            pe();
            var p = null,
                q = void 0,
                r = void 0;
            if (aq.length) {
                var u = aq.shift();
                p = u.message;
                q = u.debugContext;
                r = !0
            }
            null == p && (p = $p.shift());
            if (null != p) {
                var t = jo(p);
                if (t) {
                    p = lo(p);
                    for (var v = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], y = 0; y < v.length; y++) {
                        var x = v[y],
                            w = qe(x, 1);
                        if (pa(w) || vb(w)) w = P(w);
                        oe[x] = w
                    }
                }
                try {
                    if (na(p)) try {
                        p.call(re)
                    } catch (I) {} else if (pa(p)) {
                        var A = p;
                        if (k(A[0])) {
                            var z = A[0].split("."),
                                D = z.pop(),
                                C = A.slice(1),
                                E = qe(z.join("."), 2);
                            if (null != E) try {
                                E[D].apply(E, C)
                            } catch (I) {}
                        }
                    } else {
                        if (ya(p)) {
                            a: {
                                if (p.length && k(p[0])) {
                                    var F = Bp[p[0]];
                                    if (F && (!t || !Cp[p[0]])) {
                                        p = F(p, q, r);
                                        break a
                                    }
                                }
                                p = void 0
                            }
                            if (!p) {
                                cq = !1;
                                continue
                            }
                        }
                        a = fq(p) || a;
                        if (gq(p)) {
                            var K = p["gtm.uniqueEventId"];
                            void 0 !== K && (iq(K), Yp = K)
                        }
                    }
                } finally {
                    t && pe(!0)
                }
            }
            cq = !1
        }
        return !a
    }

    function jq() {
        var b = hq();
        try {
            Dp(Ih.H)
        } catch (c) {}
        return b
    }

    function po(a) {
        var b = a.notBeforeEventId;
        Yp < b ? (Zp[String(b)] = Zp[String(b)] || [], Zp[String(b)].push(a)) : (aq.push(a), aq.sort(ro), J(function() {
            cq || hq()
        }))
    }

    function iq(a) {
        for (var b = Zp[String(a)] || [], c = 0; c < b.length; c++) aq.push(b[c]);
        b.length && aq.sort(ro);
        delete Zp[String(a)]
    }
    var lq = function() {
            var a = ab(Zd.W, []),
                b = ab("google_tag_manager", {});
            Zp = no().get();
            iq(0);
            qo();
            b = b[Zd.W] = b[Zd.W] || {};
            bj(function() {
                if (!b.gtmDom) {
                    b.gtmDom = !0;
                    var e = {};
                    a.push((e.event = "gtm.dom", e))
                }
            });
            Ip(function() {
                if (!b.gtmLoad) {
                    b.gtmLoad = !0;
                    var e = {};
                    a.push((e.event = "gtm.load", e))
                }
            });
            b.subscribers = (b.subscribers || 0) + 1;
            var c = a.push;
            a.push = function() {
                var e;
                if (0 < T.SANDBOXED_JS_SEMAPHORE) {
                    e = [];
                    for (var f = 0; f < arguments.length; f++) e[f] = new ko(arguments[f])
                } else e = [].slice.call(arguments, 0);
                $p.push.apply($p, e);
                var g = c.apply(a, e);
                if (300 < this.length)
                    for (S(4); 300 < this.length;) this.shift();
                var l = "boolean" !== typeof g || g;
                return hq() && l
            };
            var d = a.slice(0);
            $p.push.apply($p, d);
            if (kq()) {
                J(jq)
            }
        },
        kq = function() {
            var a = !0;
            return a
        };

    function mq(a) {
        if (null == a || 0 === a.length) return !1;
        var b = Number(a),
            c = B();
        return b < c + 3E5 && b > c - 9E5
    };
    var nq = {};
    nq.ud = new String("undefined");
    var qq = function(a, b, c) {
            var d = {
                event: b,
                "gtm.element": a,
                "gtm.elementClasses": qb(a, "className"),
                "gtm.elementId": a["for"] || lb(a, "id") || "",
                "gtm.elementTarget": a.formTarget || qb(a, "target") || ""
            };
            c && (d["gtm.triggers"] = c.join(","));
            d["gtm.elementUrl"] = (a.attributes && a.attributes.formaction ? a.formAction : "") || a.action || qb(a, "href") || a.src || a.code || a.codebase || "";
            return d
        },
        rq = function(a) {
            T.hasOwnProperty("autoEventsSettings") || (T.autoEventsSettings = {});
            var b = T.autoEventsSettings;
            b.hasOwnProperty(a) || (b[a] = {});
            return b[a]
        },
        sq = function(a, b, c) {
            rq(a)[b] = c
        },
        tq = function(a, b, c, d) {
            var e = rq(a),
                f = Ea(e, b, d);
            e[b] = c(f)
        },
        uq = function(a, b, c) {
            var d = rq(a);
            return Ea(d, b, c)
        };
    var Oq = G.clearTimeout,
        Pq = G.setTimeout,
        W = function(a, b, c, d) {
            if (bk()) {
                b && J(b)
            } else return fb(a, b, c, d)
        },
        Qq = function() {
            return new Date
        },
        Rq = function() {
            return G.location.href
        },
        Sq = function(a) {
            return Oe(Qe(a), "fragment")
        },
        Tq = function(a) {
            return Pe(Qe(a))
        },
        Uq = function(a, b) {
            return qe(a, b || 2)
        },
        Vq = function(a, b, c) {
            var d;
            b ? (a.eventCallback = b, c && (a.eventTimeout = c), d = dq(a)) : d = dq(a);
            return d
        },
        Wq = function(a, b) {
            G[a] = b
        },
        X = function(a, b,
            c) {
            b && (void 0 === G[a] || c && !G[a]) && (G[a] = b);
            return G[a]
        },
        Xq = function(a, b, c) {
            return uf(a, b, void 0 === c ? !0 : !!c)
        },
        Yq = function(a, b, c) {
            return 0 === Df(a, b, c)
        },
        Zq = function(a, b) {
            if (bk()) {
                b && J(b)
            } else hb(a, b)
        },
        $q = function(a) {
            return !!uq(a, "init", !1)
        },
        ar = function(a) {
            sq(a, "init", !0)
        },
        br = function(a, b, c) {
            zi && (wb(a) || Ni(c, b, a))
        };
    var zr = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];

    function Ar(a, b) {
        a = String(a);
        b = String(b);
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) === c
    }
    var Br = new ta;

    function Cr(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + d,
                f = Br.get(e);
            f || (f = new RegExp(b, d), Br.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function Dr(a, b) {
        function c(g) {
            var l = Qe(g),
                m = Oe(l, "protocol"),
                n = Oe(l, "host", !0),
                p = Oe(l, "port"),
                q = Oe(l, "path").toLowerCase().replace(/\/$/, "");
            if (void 0 === m || "http" === m && "80" === p || "https" === m && "443" === p) m = "web", p = "default";
            return [m, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function Er(a) {
        return Fr(a) ? 1 : 0
    }

    function Fr(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Array.isArray(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = P(a, {});
                P({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (Er(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return 0 <= String(b).indexOf(String(c));
            case "_css":
                var f;
                a: {
                    if (b) try {
                        for (var g = 0; g < zr.length; g++) {
                            var l = zr[g];
                            if (b[l]) {
                                f = b[l](c);
                                break a
                            }
                        }
                    } catch (m) {}
                    f = !1
                }
                return f;
            case "_ew":
                return Ar(b, c);
            case "_eq":
                return String(b) === String(c);
            case "_ge":
                return Number(b) >= Number(c);
            case "_gt":
                return Number(b) > Number(c);
            case "_lc":
                return 0 <= String(b).split(",").indexOf(String(c));
            case "_le":
                return Number(b) <= Number(c);
            case "_lt":
                return Number(b) < Number(c);
            case "_re":
                return Cr(b, c, a.ignore_case);
            case "_sw":
                return 0 === String(b).indexOf(String(c));
            case "_um":
                return Dr(b, c)
        }
        return !1
    };
    Object.freeze({
        dl: 1,
        id: 1
    });
    Object.freeze(["config", "event", "get", "set"]);
    var Kr = encodeURI,
        Y = encodeURIComponent,
        Lr = ib;
    var Mr = function(a, b) {
            if (!a) return !1;
            var c = Oe(Qe(a), "host");
            if (!c) return !1;
            for (var d = 0; b && d < b.length; d++) {
                var e = b[d] && b[d].toLowerCase();
                if (e) {
                    var f = c.length - e.length;
                    0 < f && "." != e.charAt(0) && (f--, e = "." + e);
                    if (0 <= f && c.indexOf(e, f) == f) return !0
                }
            }
            return !1
        },
        Nr = function(a, b, c) {
            for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
            return e ? d : null
        };
    var Or = function(a, b, c) {
        for (var d = 0; d < b.length; d++) a.hasOwnProperty(b[d]) && (a[b[d]] = c(a[b[d]]))
    };

    function nt() {
        return G.gaGlobal = G.gaGlobal || {}
    }
    var ot = function() {
            var a = nt();
            a.hid = a.hid || sa();
            return a.hid
        },
        pt = function(a, b) {
            var c = nt();
            if (void 0 == c.vid || b && !c.from_cookie) c.vid = a, c.from_cookie = b
        };
    var Xt = function() {
        if (na(G.__uspapi)) {
            var a = "";
            try {
                G.__uspapi("getUSPData", 1, function(b, c) {
                    if (c && b) {
                        var d = b.uspString;
                        d && RegExp("^[\\da-zA-Z-]{1,20}$").test(d) && (a = d)
                    }
                })
            } catch (b) {}
            return a
        }
    };
    var Eu = window,
        Fu = document,
        Gu = function(a) {
            var b = Eu._gaUserPrefs;
            if (b && b.ioo && b.ioo() || a && !0 === Eu["ga-disable-" + a]) return !0;
            try {
                var c = Eu.external;
                if (c && c._gaUserPrefs && "oo" == c._gaUserPrefs) return !0
            } catch (f) {}
            for (var d = of ("AMP_TOKEN", String(Fu.cookie), !0), e = 0; e < d.length; e++)
                if ("$OPT_OUT" == d[e]) return !0;
            return Fu.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var Hu = {};

    function Su(a) {
        delete a.eventModel[R.sb];
        Zu(a.eventModel)
    }
    var Zu = function(a) {
        wa(a, function(c) {
            "_" === c.charAt(0) && delete a[c]
        });
        var b = a[R.Fa] || {};
        wa(b, function(c) {
            "_" === c.charAt(0) && delete b[c]
        })
    };
    var ov = function(a, b, c) {
            Un(b, c, a)
        },
        pv = function(a, b, c) {
            Un(b, c, a, !0)
        },
        rv = function(a, b) {};

    function qv(a, b) {}
    var Z = {
        g: {}
    };
    Z.g.gaawc = ["google"],
        function() {
            var a = !1;
            (function(b) {
                Z.__gaawc = b;
                Z.__gaawc.h = "gaawc";
                Z.__gaawc.isVendorTemplate = !0;
                Z.__gaawc.priorityOverride = 10
            })(function(b) {
                var c = String(b.vtp_measurementId);
                if (k(c) && 0 === c.indexOf("G-")) {
                    var d = Nr(b.vtp_fieldsToSet, "name", "value") || {};
                    if (d.hasOwnProperty(R.Fa) || b.vtp_userProperties) {
                        var e = d[R.Fa] || {};
                        P(Nr(b.vtp_userProperties,
                            "name", "value"), e);
                        d[R.Fa] = e
                    }
                    b.vtp_enableSendToServerContainer && b.vtp_serverContainerUrl && (d[R.U] = b.vtp_serverContainerUrl, d[R.xc] = !0);
                    var f = b.vtp_userDataVariable;
                    f && (d[R.ya] = f);
                    Or(d, R.De, function(l) {
                        return Aa(l)
                    });
                    Or(d, R.Ee, function(l) {
                        return Number(l)
                    });
                    d.send_page_view = b.vtp_sendPageView;
                    if (a) {
                        var g = d[R.U] || Uq(R.U, 2);
                        gk(c, g, !0);
                        d[R.Ie] = !0;
                        oo(ho(c, d), b.vtp_gtmEventId, cj(b.vtp_gtmEntityIndex, b.vtp_gtmEntityName))
                    } else Vn(d, c);
                    J(b.vtp_gtmOnSuccess)
                } else J(b.vtp_gtmOnFailure)
            });
        }();




    Z.g.c = ["google"],
        function() {
            (function(a) {
                Z.__c = a;
                Z.__c.h = "c";
                Z.__c.isVendorTemplate = !0;
                Z.__c.priorityOverride = 0
            })(function(a) {
                br(a.vtp_value, "c", a.vtp_gtmEventId);
                return a.vtp_value
            })
        }();
    Z.g.e = ["google"],
        function() {
            (function(a) {
                Z.__e = a;
                Z.__e.h = "e";
                Z.__e.isVendorTemplate = !0;
                Z.__e.priorityOverride = 0
            })(function(a) {
                return String(a.vtp_gtmCachedValues.event)
            })
        }();
    Z.g.f = ["google"],
        function() {
            (function(a) {
                Z.__f = a;
                Z.__f.h = "f";
                Z.__f.isVendorTemplate = !0;
                Z.__f.priorityOverride = 0
            })(function(a) {
                var b = Uq("gtm.referrer", 1) || H.referrer;
                return b ? a.vtp_component && "URL" != a.vtp_component ? Oe(Qe(String(b)), a.vtp_component, a.vtp_stripWww, a.vtp_defaultPages, a.vtp_queryKey) : Tq(String(b)) : String(b)
            })
        }();
    Z.g.cl = ["google"],
        function() {
            function a(b) {
                var c = b.target;
                if (c) {
                    var d = qq(c, "gtm.click");
                    Vq(d)
                }
            }(function(b) {
                Z.__cl = b;
                Z.__cl.h = "cl";
                Z.__cl.isVendorTemplate = !0;
                Z.__cl.priorityOverride = 0
            })(function(b) {
                if (!$q("cl")) {
                    var c = X("document");
                    jb(c, "click", a, !0);
                    ar("cl")
                }
                J(b.vtp_gtmOnSuccess)
            })
        }();
    Z.g.u = ["google"],
        function() {
            var a = function(b) {
                return {
                    toString: function() {
                        return b
                    }
                }
            };
            (function(b) {
                Z.__u = b;
                Z.__u.h = "u";
                Z.__u.isVendorTemplate = !0;
                Z.__u.priorityOverride = 0
            })(function(b) {
                var c;
                c = (c = b.vtp_customUrlSource ? b.vtp_customUrlSource : Uq("gtm.url", 1)) || Rq();
                var d = b[a("vtp_component")];
                if (!d || "URL" == d) return Tq(String(c));
                var e = Qe(String(c)),
                    f;
                if ("QUERY" === d) a: {
                    var g = b[a("vtp_multiQueryKeys").toString()],
                        l = b[a("vtp_queryKey").toString()] || "",
                        m = b[a("vtp_ignoreEmptyQueryParam").toString()],
                        n;g ? pa(l) ?
                    n = l : n = String(l).replace(/\s+/g, "").split(",") : n = [String(l)];
                    for (var p = 0; p < n.length; p++) {
                        var q = Oe(e, "QUERY", void 0, void 0, n[p]);
                        if (void 0 != q && (!m || "" !== q)) {
                            f = q;
                            break a
                        }
                    }
                    f = void 0
                }
                else f = Oe(e, d, "HOST" == d ? b[a("vtp_stripWww")] : void 0, "PATH" == d ? b[a("vtp_defaultPages")] : void 0);
                return f
            })
        }();
    Z.g.v = ["google"],
        function() {
            (function(a) {
                Z.__v = a;
                Z.__v.h = "v";
                Z.__v.isVendorTemplate = !0;
                Z.__v.priorityOverride = 0
            })(function(a) {
                var b = a.vtp_name;
                if (!b || !b.replace) return !1;
                var c = Uq(b.replace(/\\\./g, "."), a.vtp_dataLayerVersion || 1),
                    d = void 0 !== c ? c : a.vtp_defaultValue;
                br(d, "v", a.vtp_gtmEventId);
                return d
            })
        }();
    Z.g.ua = ["google"],
        function() {
            function a(m, n) {
                for (var p in m)
                    if (!l[p] && m.hasOwnProperty(p)) {
                        var q = g[p] ? Aa(m[p]) : m[p];
                        "anonymizeIp" != p || q || (q = void 0);
                        n[p] = q
                    }
            }

            function b(m) {
                var n = {};
                m.vtp_gaSettings && P(Nr(m.vtp_gaSettings.vtp_fieldsToSet, "fieldName", "value"), n);
                P(Nr(m.vtp_fieldsToSet, "fieldName", "value"), n);
                Aa(n.urlPassthrough) && (n._useUp = !0);
                m.vtp_transportUrl && (n._x_19 = m.vtp_transportUrl);
                return n
            }

            function c(m, n) {
                return void 0 === n ? n : m(n)
            }

            function d(m, n, p) {}

            function e(m, n) {
                if (!f) {
                    var p = m.vtp_useDebugVersion ? "u/analytics_debug.js" : "analytics.js";
                    m.vtp_useInternalVersion && !m.vtp_useDebugVersion && (p = "internal/" + p);
                    f = !0;
                    var q = m.vtp_gtmOnFailure,
                        r = Yj(n._x_19, "/analytics.js"),
                        u = dk("https:", "http:", "//www.google-analytics.com/" + p, n && !!n.forceSSL);
                    W("analytics.js" === p && r ? r :
                        u,
                        function() {
                            var t = Gj();
                            t && t.loaded || q();
                        }, q)
                }
            }
            var f, g = {
                    allowAnchor: !0,
                    allowLinker: !0,
                    alwaysSendReferrer: !0,
                    anonymizeIp: !0,
                    cookieUpdate: !0,
                    exFatal: !0,
                    forceSSL: !0,
                    javaEnabled: !0,
                    legacyHistoryImport: !0,
                    nonInteraction: !0,
                    useAmpClientId: !0,
                    useBeacon: !0,
                    storeGac: !0,
                    allowAdFeatures: !0,
                    allowAdPersonalizationSignals: !0,
                    _cd2l: !0
                },
                l = {
                    urlPassthrough: !0
                };
            (function(m) {
                Z.__ua =
                    m;
                Z.__ua.h = "ua";
                Z.__ua.isVendorTemplate = !0;
                Z.__ua.priorityOverride = 0
            })(function(m) {
                function n() {
                    if (m.vtp_doubleClick || "DISPLAY_FEATURES" == m.vtp_advertisingFeaturesType) v.displayfeatures = !0
                }
                var p = {},
                    q = {},
                    r = {};
                if (m.vtp_gaSettings) {
                    var u = m.vtp_gaSettings;
                    P(Nr(u.vtp_contentGroup, "index", "group"), p);
                    P(Nr(u.vtp_dimension, "index", "dimension"), q);
                    P(Nr(u.vtp_metric, "index", "metric"), r);
                    var t = P(u);
                    t.vtp_fieldsToSet = void 0;
                    t.vtp_contentGroup = void 0;
                    t.vtp_dimension = void 0;
                    t.vtp_metric = void 0;
                    m = P(m, t)
                }
                P(Nr(m.vtp_contentGroup,
                    "index", "group"), p);
                P(Nr(m.vtp_dimension, "index", "dimension"), q);
                P(Nr(m.vtp_metric, "index", "metric"), r);
                var v = b(m),
                    y = String(m.vtp_trackingId || ""),
                    x = "",
                    w = "",
                    A = "";
                m.vtp_setTrackerName && "string" == typeof m.vtp_trackerName ? "" !== m.vtp_trackerName && (A = m.vtp_trackerName, w = A + ".") : (A = "gtm" + ke(), w = A + ".");
                var z = function(V, Q) {
                    for (var da in Q) Q.hasOwnProperty(da) && (v[V + da] = Q[da])
                };
                z("contentGroup", p);
                z("dimension", q);
                z("metric", r);
                m.vtp_enableEcommerce && (x = m.vtp_gtmCachedValues.event, v.gtmEcommerceData = d(m, v, x));
                if ("TRACK_EVENT" === m.vtp_trackType) x = "track_event", n(), v.eventCategory = String(m.vtp_eventCategory), v.eventAction = String(m.vtp_eventAction), v.eventLabel = c(String, m.vtp_eventLabel), v.value = c(za, m.vtp_eventValue);
                else if ("TRACK_PAGEVIEW" == m.vtp_trackType) {
                    if (x = R.jc, n(), "DISPLAY_FEATURES_WITH_REMARKETING_LISTS" == m.vtp_advertisingFeaturesType && (v.remarketingLists = !0), m.vtp_autoLinkDomains) {
                        var D = {};
                        D[R.M] = m.vtp_autoLinkDomains;
                        D.use_anchor = m.vtp_useHashAutoLink;
                        D[R.Ob] = m.vtp_decorateFormsAutoLink;
                        v[R.la] =
                            D
                    }
                } else "TRACK_SOCIAL" === m.vtp_trackType ? (x = "track_social", v.socialNetwork = String(m.vtp_socialNetwork), v.socialAction = String(m.vtp_socialAction), v.socialTarget = String(m.vtp_socialActionTarget)) : "TRACK_TIMING" == m.vtp_trackType && (x = "timing_complete", v.eventCategory = String(m.vtp_timingCategory), v.timingVar = String(m.vtp_timingVar), v.value = za(m.vtp_timingValue), v.eventLabel = c(String, m.vtp_timingLabel));
                m.vtp_enableRecaptcha && (v.enableRecaptcha = !0);
                m.vtp_enableLinkId && (v.enableLinkId = !0);
                var C = {};
                a(v, C);
                v.name || (C.gtmTrackerName = A);
                C.gaFunctionName = m.vtp_functionName;
                void 0 !== m.vtp_nonInteraction && (C.nonInteraction = m.vtp_nonInteraction);
                var E = sk(pk(jk(C), m.vtp_gtmOnSuccess), m.vtp_gtmOnFailure);
                E.isGtmEvent = !0;
                pn(y, x, Date.now(), E);
                var F = Ij(m.vtp_functionName);
                if (na(F)) {
                    var K = function(V) {
                        var Q = [].slice.call(arguments, 0);
                        Q[0] = w + Q[0];
                        F.apply(window, Q)
                    };
                    if ("TRACK_TRANSACTION" == m.vtp_trackType) {} else if ("DECORATE_LINK" == m.vtp_trackType) {} else if ("DECORATE_FORM" == m.vtp_trackType) {} else if ("TRACK_DATA" == m.vtp_trackType) {}
                    e(m, v)
                } else J(m.vtp_gtmOnFailure)
            })
        }();



    Z.g.gas = ["google"],
        function() {
            (function(a) {
                Z.__gas = a;
                Z.__gas.h = "gas";
                Z.__gas.isVendorTemplate = !0;
                Z.__gas.priorityOverride = 0
            })(function(a) {
                var b = P(a),
                    c = b;
                c[xb.tb] = null;
                c[xb.Ge] = null;
                var d = b = c;
                d.vtp_fieldsToSet = d.vtp_fieldsToSet || [];
                var e = d.vtp_cookieDomain;
                void 0 !== e && (d.vtp_fieldsToSet.push({
                    fieldName: "cookieDomain",
                    value: e
                }), delete d.vtp_cookieDomain);
                return b
            })
        }();













    var sv = {};
    sv.dataLayer = re;
    sv.callback = function(a) {
        ie.hasOwnProperty(a) && na(ie[a]) && ie[a]();
        delete ie[a]
    };
    sv.bootstrap = 0;
    sv._spx = !1;
    (function(a) {
        if (!G["__TAGGY_INSTALLED"]) {
            var b = !1;
            if (H.referrer) {
                var c = Qe(H.referrer);
                b = "cct.google" === Ne(c, "host")
            }
            if (!b) {
                var d = uf("googTaggyReferrer");
                b = d.length && d[0].length
            }
            b && (G["__TAGGY_INSTALLED"] = !0, fb("https://cct.google/taggy/agent.js"))
        }
        var f = function(q) {
                var r = "GTM",
                    u = "GTM";
                var t = G["google.tagmanager.debugui2.queue"];
                t || (t = [], G["google.tagmanager.debugui2.queue"] = t, fb("https://" + Zd.hc + "/debug/bootstrap?id=" + Ih.H + "&src=" + u + "&cond=" + q + "&gtm=" + yk()));
                var v = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: $a,
                        containerProduct: r,
                        debug: !1,
                        id: Ih.H
                    }
                };
                v.data.resume = function() {
                    a()
                };
                Zd.uh && (v.data.initialPublish = !0);
                t.push(v)
            },
            g = void 0,
            l = Oe(G.location, "query", !1, void 0, "gtm_debug");
        mq(l) && (g = 2);
        if (!g && H.referrer) {
            var m = Qe(H.referrer);
            "tagassistant.google.com" === Ne(m, "host") && (g = 3)
        }
        if (!g) {
            var n = uf("__TAG_ASSISTANT");
            n.length && n[0].length && (g = 4)
        }
        if (!g) {
            var p = H.documentElement.getAttribute("data-tag-assistant-present");
            mq(p) && (g = 5)
        }
        g && $a ? f(g) : a()
    })(function() {
        var a = !1;
        a && Cj("INIT");
        Xc().o();
        Vk();
        Jg.enable_gbraid_cookie_write = !0;
        var b = !!T[Ih.H];
        if (b) {
            var c = T.zones;
            c && c.unregisterChild(Kh());
        } else {
            for (var d = Lh(), e = 0; e < d.length; e++) uo(d[e], Ih.H);
            for (var f = data.resource || {}, g = f.macros || [], l = 0; l < g.length; l++) Vb.push(g[l]);
            for (var m = f.tags || [], n = 0; n < m.length; n++) Yb.push(m[n]);
            for (var p = f.predicates || [], q = 0; q < p.length; q++) Xb.push(p[q]);
            for (var r = f.rules || [], u = 0; u < r.length; u++) {
                for (var t = r[u], v = {}, y = 0; y < t.length; y++) v[t[y][0]] = Array.prototype.slice.call(t[y], 1);
                Wb.push(v)
            }
            $b = Z;
            cc = Er;
            T[Ih.H] = sv;
            for (var x = Nh(), w = Kh(), A = 0; A < w.length; A++) x.container[w[A]] = !0;
            for (var z = Lh(), D = 0; D < z.length; D++) x.destination[z[D]] = !0;
            x.canonical[Ih.fc] = !0;
            Ha(je, Z.g);
            ec = mc;
            lq();
            Xi = !1;
            Yi = 0;
            if ("interactive" == H.readyState &&
                !H.createEventObject || "complete" == H.readyState) $i();
            else {
                jb(H, "DOMContentLoaded", $i);
                jb(H, "readystatechange", $i);
                if (H.createEventObject && H.documentElement.doScroll) {
                    var C = !0;
                    try {
                        C = !G.frameElement
                    } catch (O) {}
                    C && aj()
                }
                jb(G, "load", $i)
            }
            Fp = !1;
            "complete" === H.readyState ? Hp() : jb(G, "load", Hp);
            zi && G.setInterval(si,
                864E5);
            he = B();
            if (a) {
                var I = Dj("INIT");
            }
        }
    });

})()